import argparse
import collections
import contextlib
import itertools
import json
import jsonschema
import logging
import os
import re
import setuptools
import shutil
import sys
import tempfile
import subprocess
import ruxit.tools.sdk_version
from ruxit.tools import plugin_upload
from ruxit.tools.default_dir_provider import DefaultDirProvider

from ruxit.package_utils.plugin_updater import process_types


logging.basicConfig(stream=sys.stderr, format="%(message)s", level=logging.INFO)
log = logging.getLogger(__package__)

UNITS = [
    "NanoSecond",
    "MicroSecond",
    "MilliSecond",
    "Second",
    "Byte",
    "KiloByte",
    "KibiByte",
    "MegaByte",
    "MebiByte",
    "BytePerSecond",
    "BytePerMinute",
    "KiloBytePerSecond",
    "KiloBytePerMinute",
    "KibiBytePerSecond",
    "KibiBytePerMinute",
    "MegaBytePerSecond",
    "MegaBytePerMinute",
    "MebiBytePerSecond",
    "MebiBytePerMinute",
    "Ratio",
    "Percent",
    "Promille",
    "Count",
    "PerSecond",
    "PerMinute",
    "Unspecified",
    "NotApplicable",
]

ENTITY_TYPES = [
    "HOST",
    "PROCESS_GROUP_INSTANCE",
    "PROCESS_GROUP"
]

GENERIC_EVENT_TYPES = [
    "PERFORMANCE_EVENT",
    "AVAILABILITY_EVENT",
    "ERROR_EVENT"
]

GENERIC_EVENT_CONDITION = [
    "ABOVE",
    "BELOW",
]




REQUIRED_TIMESERIES = [
    "key",
    "unit",
    "displayname",
]

REQUIRED_STATE_TIMESERIES = [
    "key",
    "states",
    "displayname",
]





def _i(items):
    return [i.capitalize() for i in items] + [i.upper() for i in items] + [i.lower() for i in items]


PROPERTY_TYPES = _i(['STRING', 'BOOLEAN', 'INTEGER', 'FLOAT', 'PASSWORD', 'JSON', 'TEXTAREA', 'DROPDOWN'])
AGGREGATION_TYPES = _i(["MIN", "MAX", "AVG", "SUM", "COUNT", "P50", "P90"])
MERGEAGGREGATION_TYPES = _i(["MIN", "MAX", "AVG", "SUM"])
SERIES_TYPES = _i(["LINE", "AREA", "BAR"])



NAME_PATTERN = r"^([a-zA-Z][a-zA-Z0-9_-]*)(\.[a-zA-Z][a-zA-Z0-9_-]*)*$"


chart_schema = {
    "type": "array",
    "items": {
        "type": "object",
        "required": ["title", "group", "series"],
        "properties": {
            "title": {"type": "string", "minLength": 1},
            "description": {"type": "string", "minLength": 1},
            "group": {"type": "string", "minLength": 1},
            "series": {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "required": ["key"],
                    "properties": {
                        "key": {"type": "string", "minLength": 1},
                        "color": {"type": "string"},
                        "aggeragation": {"type": "string", "enum": AGGREGATION_TYPES},
                        "mergeaggregation": {"type": "string", "enum": MERGEAGGREGATION_TYPES},
                        "dimensions": {"type": "array", "minItems": 1, "items": {"type": "string", "minLength": 1}},
                        "seriestype": {"type": "string", "enum": SERIES_TYPES},
                        "stacked": {"type": "boolean"},
                        "rightaxis": {"type": "boolean"},
                        "displayname": {"type": "string", "minLength": 1},
                        "unit": {"type": "string", "minLength": 1},
                    }
                }
            }
        }
    }
}

generic_alert_schema = {
    "type": "array",
    "minItems": 1,
    "items": {
        "type": "object",
        "required": ["event_type", "alert_condition", 'alert_id', 'event_name', 'threshold', 'samples',
                     'violating_samples', 'dealerting_samples'],
        "properties": {

            "event_type": {"type": "string", "enum": GENERIC_EVENT_TYPES},
            "alert_condition": {"type": "string", "enum": GENERIC_EVENT_CONDITION},

            "alert_id": {
                "type": "string", "minLength": 1,
                "pattern": NAME_PATTERN,
            },
            "event_name": {
                "type": "string", "minLength": 1,
            },
            "threshold": {
                "type": "number",
                "minimum": 0
            },
            "samples": {
                "type": "integer",
                "minimum": 1
            },

            "violating_samples": {
                "type": "integer",
                "minimum": 1
            },
            "dealerting_samples": {
                "type": "integer",
                "minimum": 1
            },
        }
    }
}



CUSTOM_PLUGIN_NAME = r"^custom.(remote\.)?(jmx|pmi|python)(\.[a-zA-Z][a-zA-Z0-9_-]*)+$"



plugin_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "required": ["name", "version", "type", "entity", "metrics"],
    "properties": {
        "name": {
            "type": "string", "minLength": 1,
            "description": "The plugin name",
            "pattern":CUSTOM_PLUGIN_NAME,
        },
        "version": {
            "type": "string",
            "description": "The plugin version",
            "pattern": r"^\d+\.\d+$",
        },
        "type": {
            "type": "string",
            "description": "The plugin type",
            "enum": ["perfmon", "JMX", "python"],
        },
        "entity": {
            "type": "string",
            "description": "Entity type upon which the plugin is activated",
            "enum": ["PROCESS_GROUP_INSTANCE", "HOST", "CUSTOM_DEVICE", "CUSTOM_DEVICE_GROUP"],
        },
        "processTypes": {
            "type": "array",
            "items": {
                "type": "integer",
                "minimum": 0
            },
            "minItems": 1,
            "uniqueItems": True
        },
        "processTypeNames": {
            "type": "array",
            "items": {
                "enum": [x for x in process_types.keys()],
            },
            "minItems": 1,
            "uniqueItems": True
        },
        "technologies": {
            "type": "array",
            "items": {
                "type": "string"
            },
            "uniqueItems": True
        },
        "metrics": {
            "type": "array",
            "items": {
                "oneOf": [
                    {
                        "type": "object",
                        "required": ["timeseries"],
                        "properties": {
                            "timeseries": {
                                "type": "object",
                                "required":REQUIRED_TIMESERIES,
                                "properties": {
                                    "key": {
                                        "type": "string", "minLength": 1,
                                        "pattern": NAME_PATTERN,
                                    },
                                    "unit": {
                                        "type": "string",
                                        "enum": UNITS
                                    },
                                    "dimensions": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength":1,"pattern": NAME_PATTERN}
                                    },
                                    "entity": {
                                        "type": "string",
                                        "enum": ENTITY_TYPES
                                    },
                                    "displayname":{
                                        "type": "string", "minLength": 1
                                    }
                                }
                            },
                            "alert_settings": generic_alert_schema

                        }
                    },
                    {
                        "type": "object",
                        "required": ["statetimeseries"],
                        "properties": {
                            "statetimeseries": {
                                "type": "object",
                                "required": REQUIRED_STATE_TIMESERIES,
                                "properties": {
                                    "key": {
                                        "type": "string", "minLength": 1,
                                        "pattern":NAME_PATTERN,
                                    },
                                    "dimensions": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength":1,"pattern": NAME_PATTERN}
                                    },
                                    "states": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength": 1,"pattern": NAME_PATTERN}
                                    },

                                    "entity": {
                                        "type": "string",
                                        "enum": ENTITY_TYPES
                                    },
                                    "displayname":{
                                        "type": "string", "minLength": 1
                                    }
                                }
                            }
                        },
                        "alert_settings": generic_alert_schema
                    },
                ]
            },
        },
        "properties": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["key", "type"],
                "properties": {
                    "key": {"type": "string", "minLength": 1},
                    "type": {"type": "string", "enum": PROPERTY_TYPES}
                }
            }
        },
        "ui": {
            "type": "object",
            "properties": {
                "keyMetrics": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 2,
                    "items": {
                        "type": "object",
                        "required": ["key"],
                        "properties": {
                            "key": {"type": "string", "minLength": 1},
                            "aggregation": {"type": "string", "enum": AGGREGATION_TYPES},
                            "mergeaggregation": {"type": "string", "enum": MERGEAGGREGATION_TYPES},
                            "displayname": {"type": "string", "minLength": 1}
                        }
                    }
                },
                "keycharts": chart_schema,
                "charts": chart_schema
            }
        },
        "configUI": {
            "type": "object",
            "properties": {
                "displayName": {"type": "string", "minLength": 1},
                "properties": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "key": {"type": "string", "minLength": 1},
                            "displayName": {"type": "string", "minLength": 1},
                            "displayOrder": {"type": "integer", "minimum": 1},
                        }
                    }
                }
            }
        },
        "source": {},
    },
}


@contextlib.contextmanager
def work_in_dir(path):
    _cwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        log.info("Leaving directory %s", path)
        os.chdir(_cwd)


class PluginMetadata:
    def __init__(self, raw_json):
        self.raw_json = raw_json

    def _query_raw_json_param(self, param_name, query):
        try:
            return query(self.raw_json)
        except KeyError as ex:
            raise Exception("Unable to access %s in plugin.json" % param_name) from ex

    @property
    def plugin_name(self):
        return self._query_raw_json_param("name", lambda js: js['name'])

    @property
    def package_name(self):
        return self._query_raw_json_param("package name", lambda js: js['source']['package'])

    @property
    def plugin_version(self):
        version = self._query_raw_json_param("plugin version", lambda js: js['version'])
        package_version_re = r'^\d+\.\d+$'
        if not re.match(package_version_re, version):
            raise Exception("Expected plugin version to be in format MAJOR.MINOR, found %s" % version)
        return version

    @property
    def install_requires(self):
        return self.raw_json.get('source', {}).get('install_requires', [])

    @property
    def package_data(self):
        return self.raw_json.get('source', {}).get('package_data', {})

    @property
    def packages(self):
        return self.raw_json.get('source', {}).get('packages', [])

    @property
    def pymodules(self):
        _pymodules = self.raw_json.get('source', {}).get('modules', [])
        return _pymodules or [self.package_name]

    @property
    def timeseries(self):
        return [m['timeseries'] for m in self.raw_json["metrics"] if "timeseries" in m]

    @property
    def timeseries_by_key(self):
        return {tm['key']: tm for tm in self.timeseries}

    @property
    def statetimeseries(self):
        return [m["statetimeseries"] for m in self.raw_json["metrics"] if "statetimeseries" in m]

    @property
    def statetimeseries_by_key(self):
        return {tm['key']: tm for tm in self.statetimeseries}

    @property
    def properties(self):
        return [p for p in self.raw_json.get("properties", [])]

    @property
    def properties_by_key(self):
        return {p['key']: p for p in self.properties}

    @property
    def configui_properties(self):
        return [p for p in self.raw_json.get("configUI", {}).get("properties", [])]

    @property
    def charts(self):
        return self.raw_json.get("ui", {}).get("charts", [])

    @property
    def key_charts(self):
        return self.raw_json.get("ui", {}).get("keycharts", self.raw_json.get("ui", {}).get("keyCharts", []))

    @property
    def key_metrics(self):
        return self.raw_json.get("ui", {}).get("keyMetrics", [])

    def __str__(self):
        return "Plugin name=%s, version=%s" % (self.plugin_name, self.plugin_version)


def main():
    parsed_args = None
    try:
        parsed_args = _parse_args(sys.argv[1:])
        _main(parsed_args)
    except Exception as ex:
        log.error("Error occured: %s", ex)
        if parsed_args and parsed_args.verbose:
            log.exception("Error details:")
        sys.exit(1)


def _main(args):
    log.info("Starting oneagent_build_plugin")
    source_dir = os.path.abspath(args.source_dir)
    plugin_json_path = os.path.join(source_dir, 'plugin.json')
    meta = _validate_plugin_json(plugin_json_path)
    plugin_name = meta.plugin_name
    remote = plugin_upload.is_remote(plugin_name)
    dir_provider = DefaultDirProvider(remote)
    log.info("Plugin data: %s", meta)

    target_root = dir_provider.get_default_target_root() if not args.target_dir else args.target_dir
    target_dir = os.path.abspath(os.path.join(target_root, plugin_name))
    if os.path.abspath(source_dir) == os.path.abspath(target_dir):
        raise Exception("Source and target dir are the same, aborting")

    with tempfile.TemporaryDirectory() as tmp_wheeldir, tempfile.TemporaryDirectory() as tmp_installpath:
        produced_dist = _create_plugin_wheel(meta, source_dir, tmp_wheeldir)
        log.info("Created distribution of the plugin: %s" % produced_dist.dist_files)

        log.info("Installing plugin to temporary location")
        whlpath = produced_dist.dist_files[0][2]
        _install_plugin_wheel(tmp_installpath, whlpath)

        log.info("Copying plugin to target_directory: %s" % target_dir)
        _copy_plugin(tmp_installpath, plugin_json_path, target_dir)
        log.info("Creating plugin archive")
        archive_basename = os.path.join(target_root, plugin_name)
        archive_name = shutil.make_archive(archive_basename, "zip", root_dir=target_root, base_dir=plugin_name)

        log.info("=" * 40)
        log.info("Plugin deployed successfully into %s", target_dir)
        log.info("Plugin archive available at %s", archive_name)
        log.info("=" * 40)
    if (not args.no_restart):
        _restart_agent(remote)
    if (args.no_upload):
        return

    servers = plugin_upload.get_server_names(remote, server=None)
    if not servers:
        address = input("Enter server address: ")
        servers.append(address)
    try:
        token = plugin_upload.get_token(remote, token=None, token_file=None)
    except:
        token = None
    if token is None:
        token_param = _get_token_input()
    else:
        token_param = ("-t", token)
    for server in servers:
        if args.no_cert_ver:
            upload_command = "oneagent_upload_plugin -p {0} -s {1} {2} {3} --no_cert_ver".format(archive_name, server,
                                                                                                 token_param[0],
                                                                                                 token_param[1])
        else:
            upload_command = "oneagent_upload_plugin -p {0} -s {1} {2} {3}".format(archive_name, server, token_param[0],
                                                                                   token_param[1])
        log.info("interactive upload -> %s" % upload_command)
        token_file = None
        token = None
        if token_param[0] == "-t":
            token = token_param[1]
        else:
            token_file = token_param[1]
        upload_status = plugin_upload.main_body(archive_name, server, token, token_file, args.no_cert_ver)
        if upload_status:
            break


def _restart_agent(remote):
    log.info("Restarting service ")
    if sys.platform == 'win32':
        process_name = 'Dynatrace OneAgent' if not remote else 'Dynatrace Remote Plugin Agent'
        log.info(process_name)
        stop_status = subprocess.run(['net', 'stop', process_name])
        start_status = subprocess.run(['net', 'start', process_name])
        if stop_status.returncode != 0 and start_status.returncode != 0 and not remote:
            subprocess.run(['net', 'stop', 'Ruxit Agent']).check_returncode()
            subprocess.run(['net', 'start', 'Ruxit Agent']).check_returncode()
        else:
            stop_status.check_returncode()
            start_status.check_returncode()
    else:
        process_name = 'oneagent' if not remote else 'remoteplugin'
        log.info(process_name)
        restart = subprocess.run(['service', process_name, 'restart'])
        if restart.returncode != 0 and not remote:
            subprocess.run(['service', 'ruxitagent', 'restart']).check_returncode()
        else:
            restart.check_returncode()
    log.info("oneagent service restarted successfully")


def _get_token_input():
    is_token_file = input("Does token file exist? (Y or N; default is Y): ")
    if len(is_token_file) > 0 and is_token_file in {'n', 'N'}:
        return ("-t", input("Enter authentication token: "))
    else:
        return ("-T", input("Enter token file path : "))


def _find_duplicates(items):
    cn = collections.Counter(items)
    return [item for item, count in cn.items() if count > 1]


def _validate_duplicates(items, where):
    dup = _find_duplicates(items)
    if dup:
        raise Exception("Validating plugin.json failed, duplicate keys found in %s : %s" % (where, dup))


def _validate_plugin_json(plugin_json_path):
    json_data = _read_plugin_json(plugin_json_path)
    meta = PluginMetadata(json_data)
    try:
        _validate_meta(meta)
    except jsonschema.exceptions.ValidationError as ex:
        log.error("Validating plugin.json failed, details: %s", ex)
        raise
    # semantic checks
    _validate_duplicates((tm["key"] for tm in meta.timeseries), "plugin timeseries")
    _validate_duplicates((prop["key"] for prop in meta.properties), "plugin properties")
    _validate_duplicates((prop["key"] for prop in meta.configui_properties), "plugin configUI properties")
    props = meta.properties_by_key
    for configui_prop in meta.configui_properties:
        if configui_prop["key"] not in props:
            raise Exception(
                "Validating plugin.json failed, configUI property %s refers to non existing property" % configui_prop[
                    "key"])
        
    #we are considering all types of timeseries
    all_timeseries_by_key={**meta.timeseries_by_key,**meta.statetimeseries_by_key}
    for key_metric in meta.key_metrics:
        if key_metric["key"] not in all_timeseries_by_key:
            raise Exception(
                "Validating plugin.json failed, key metric %s refers to non existing metric" %
                (key_metric["key"])
            )
    for chart in itertools.chain(meta.key_charts, meta.charts):
        for chart_series in chart["series"]:
            if chart_series["key"] not in all_timeseries_by_key:
                raise Exception(
                    "Validating plugin.json failed, chart group:%s title:%s series:%s refers to non existing metric" %
                    (chart["group"], chart["title"], chart_series["key"])
                )
            chart_referenced_ts = all_timeseries_by_key[chart_series["key"]]
            timeseries_dimensions = set(chart_referenced_ts.get("dimensions", []))
            chart_dimensions = set(chart_series.get("dimensions", []))
            if not chart_dimensions.issubset(timeseries_dimensions):
                raise Exception(
                    "Validating plugin.json failed, chart group:%s title:%s series:%s refers to invalid dimensions, chart dimensions: %s, timeseries_dimensions: %s" %
                    (chart["group"], chart["title"], chart_series["key"], list(chart_dimensions),
                     list(timeseries_dimensions))
                )
    return meta


def _parse_args(cmd_args):
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', "--source_dir", default=os.getcwd())
    parser.add_argument('-t', "--target_dir")
    parser.add_argument("-v", "--verbose", help="increase verbosity", action="store_true")
    parser.add_argument("--no_upload", action='store_true', help="turn off upload to the server")
    parser.add_argument("--no_restart", action='store_true', help="turn off agent restart")
    parser.add_argument("--no_cert_ver", help="turn off ssl certificate verification", action="store_true")

    __version__ = ruxit.tools.sdk_version.get_version()
    parser.add_argument(
        '--version',
        action="version",
        help="show program's version and exit",
        version=('{name} {version}'.format(name=__loader__.name, version=__version__))
    )
    args = parser.parse_args(cmd_args)
    log.info("Arguments=%s", args)
    if args.verbose:
        log.setLevel(logging.DEBUG)
    return args


def _read_plugin_json(plugin_json_path):
    log.info("Checking plugin metadata: %s", plugin_json_path)
    with open(plugin_json_path, 'r') as fp:
        try:
            json_data = json.load(fp)
        except Exception as ex:
            raise Exception("Error when parsing plugin.json file: %s" % plugin_json_path) from ex
    return json_data


def _validate_meta(meta):
    meta.plugin_name and meta.package_name and meta.plugin_version
    root_validator = jsonschema.Draft4Validator(plugin_json_schema)
    log.info("Validating plugin.json against schema")
    root_validator.validate(meta.raw_json)


def _create_plugin_wheel(meta, source_dir, work_dir):
    try:
        log.info("Cleaning up previous build information")
        egg_info_path = os.path.join(source_dir, '%s.egg-info' % meta.package_name)
        if os.path.exists(egg_info_path):
            shutil.rmtree(egg_info_path)

        with work_in_dir(work_dir):
            produced_dist = setuptools.setup(
                name=meta.package_name,
                version=meta.plugin_version,
                package_dir={'': source_dir},
                py_modules=meta.pymodules,
                packages=meta.packages,
                package_data=meta.package_data,
                install_requires=meta.install_requires,
                script_args=['bdist_wheel']
            )

        if produced_dist is None:
            raise Exception("Failed to create a distribution of the plugin")
    except SystemExit as ex:
        raise Exception("Error when creating wheel package from plugin, details: %s" % ex) from ex
    return produced_dist


def _install_plugin_wheel(tmp_installpath, whlpath):
    import pip
    pip_status = pip.main([
        "install",
        '--ignore-installed',
        '--only-binary',
        '--disable-pip-version-check',
        '--target=' + tmp_installpath,
        '--upgrade',
        '--no-compile',
        whlpath]
    )
    if pip_status:
        raise Exception("Failed to install the plugin into temporary location")


def _copy_plugin(install_path, plugin_json_path, target_dir):
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    shutil.copytree(install_path, target_dir)
    shutil.copy(plugin_json_path, target_dir)
    if sys.platform.startswith("linux"):
        os.chmod(target_dir, 0o775)
        for base, dirs, files in os.walk(target_dir):
            for _dir in dirs:
                log.info(os.path.join(base, _dir))
                os.chmod(os.path.join(base, _dir), 0o775)
            for file in files:
                log.info(os.path.join(base, file))
                os.chmod(os.path.join(base, file), 0o664)


if __name__ == '__main__':
    main()
