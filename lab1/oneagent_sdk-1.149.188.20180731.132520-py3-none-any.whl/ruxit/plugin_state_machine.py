import collections
import copy
import importlib
import io
import logging
import sys
import threading
import time
import traceback
from enum import IntEnum

import ruxit.api.data
import ruxit.api.exceptions
import ruxit.api.selectors
import ruxit.config_utils
from ruxit.package_utils.class_factory import generate_state_enum, generate_state_metric
from ruxit.api.results_builder import ResultsBuilder
from ruxit.plugin_status_reporter import PluginFullStatus, PluginState
from ruxit.utils.execute_every_minute import is_interval_passed
from ruxit.utils.firewall import Firewall

ExecStat = collections.namedtuple('ExecStat', ['start_time', 'end_time', 'thread_id', 'cpu_info'])
StateData = collections.namedtuple('StateData',['states'])

WrappedPluginMeasurementList = collections.namedtuple('WrappedPluginMeasurementList', ['timestamp', 'measurements'])
WrappedPluginMeasurement = collections.namedtuple(
    'WrappedPluginMeasurement',
    ['monitoredEntityId', 'tsIdentifier', 'dimensions', 'value', 'aggregation', 'isV3', 'isStatetimeseries', 'isStatCounter']
)
Dimension = collections.namedtuple('Dimension', ['key', 'value'])

CustomPropertyProtoWrapper = collections.namedtuple(
    'CustomPropertyProtoWrapper',
    ['key', 'value', 'me_attribute']
)

WrappedEvent = collections.namedtuple('WrappedEvent', ['type', 'event_id', 'entity_id', 'me_type', 'event_metadata'])
WrappedEventMetadata = collections.namedtuple('WrappedEventMetadata', ['key', 'value', 'is_boolean', 'is_float', 'is_int',
                                                                       'is_custom_properties'])

WrappedResults = collections.namedtuple("WrappedResults", ["measurements", "properties", "events"])


class PluginStateGroups:
    errors = {PluginState.ERROR_UNKNOWN, PluginState.ERROR_CONFIG, PluginState.ERROR_AUTH}
    recoverable_errors = {PluginState.ERROR_CONFIG, PluginState.ERROR_AUTH}
    mostly_fine = {PluginState.OK, PluginState.NOTHING_TO_REPORT}

    @staticmethod
    def is_error(state):
        return state in PluginStateGroups.errors

    @staticmethod
    def is_recoverable_error(state):
        return state in PluginStateGroups.recoverable_errors

    @staticmethod
    def is_fine(state):
        return state in PluginStateGroups.mostly_fine

class AggregationTypes(IntEnum):
    avg = 1,
    sum = 4

class PluginEngine(object):
    # documented in lifecycle guide
    measure_interval_seconds = 60

    _exc_to_state = {
        ruxit.api.exceptions.ConfigException: PluginState.ERROR_CONFIG,
        ruxit.api.exceptions.AuthException: PluginState.ERROR_AUTH,
    }

    # documented in lifecycle guide
    _crash_limit = 20

    def __init__(self, *, external_api, entity_resolver, plugin_info, activation_context):
        self.plugin_info = plugin_info
        self.metadata = plugin_info.json_data
        self.config = None
        self.external_api = external_api
        self.entity_resolver = entity_resolver
        self.activation_context = activation_context

        self.logger = logging.getLogger("plugin_development." + plugin_info.reported_name) if plugin_info.is_in_development else logging.getLogger(__name__)

        self._crash_count = 0
        self._executions_count = 0
        self.execution_timeout = False
        self._engine = engine_generator(self)
        self._stats = collections.deque(maxlen=10)
        self._instance = None

        self.results_builder = ResultsBuilder(self.logger, self.external_api)

        self._selector_cache = {}
        self.last_wrapped_results = None

        self._state = None
        self.full_status = None
        self.set_full_status(PluginState.UNINITIALIZED)

        self.last_measurements_timestamp = None
        # documented in lifecycle guide
        self.config_reset_interval_seconds = 3600
        self.fast_check_id = None
        self.fast_status_ready = None

        #add custom and state metrics metadata
        self.metadata_by_metric = {}
        self.states_data = {}
        for m in self.metadata.get("metrics", []):
            metric_data = m.get("timeseries", None)
            if not metric_data:
                metric_data = m.get("statetimeseries", None)
                if not metric_data:
                    continue
                metric_key = metric_data["key"]
                self.states_data [metric_key] = PluginEngine._get_state_info(metric_data)
                generate_state_enum(plugin_info.package, metric_key, metric_data["states"])
                generate_state_metric(plugin_info.package, metric_key)
            self.metadata_by_metric[metric_data["key"]] = m

        self._start_time = time.monotonic()

    @staticmethod
    def _get_state_info(metadata):
        states = {}
        count = 0
        for state in metadata["states"]:
            states [state] = count
            count += 1
        return StateData(states)

    def get_snapshot(self):
        return self.entity_resolver.get_snapshot()

    def get_logger(self):
        return self.logger

    def ready_for_set_config(self, new_config, fast_check_id):
        #new config or fast check always run a plugin
        if new_config is None:
            return False
        if fast_check_id:
            return True
        if new_config != self.config:
            return True
        #otherwise plugin is run if interval (1 minute) is passed
        if not is_interval_passed (self._start_time, self.measure_interval_seconds, self.last_measurements_timestamp, time.monotonic()):
            return False
        if PluginStateGroups.is_error(self._state) and not self._crash_limit_exceeded():
            return True
        return PluginStateGroups.is_recoverable_error(self._state)

    def ready_for_measure(self):
        if not PluginStateGroups.is_fine(self._state):
            return False
        if self.fast_check_id:
            return True
        else:
            return is_interval_passed (self._start_time, self.measure_interval_seconds, self.last_measurements_timestamp, time.monotonic());

    def get_name(self):
        return self.metadata["name"]

    def get_id(self):
        return (
            self.metadata['name'],
            self.get_entity_id()
        )

    def is_initialized(self):
        return self._state != PluginState.UNINITIALIZED

    def set_full_status(self, state, exception_info=None):
        self._state = state
        self.full_status = PluginFullStatus(
            pluginName=self.plugin_info.reported_name,
            pluginVersion=self.metadata['version'],
            state=state.value,
            description=self._get_exception_message(exception_info) if exception_info else "",
            stacktrace=self._get_exception_stacktrace(exception_info) if exception_info else "",
            monitoredEntityId=self.get_entity_id()
        )

    def get_full_status(self):
        return self.full_status

    def _get_exception_message(self, exception_info):
        try:
            if len(exception_info[1].args) > 0:
                return str(exception_info[1].args[0])
            else:
                return ""
        except:
            self.logger.info("Exception on extracting plugin error message", exc_info=1)
            return ""

    def _get_exception_stacktrace(self, exception_info):
        try:
            stack_string = io.StringIO()
            traceback.print_exception(*exception_info, file=stack_string)
            return stack_string.getvalue()
        except:
            self.logger.info("Exception on extracting plugin error stacktrace", exc_info=1)
            return ""

    def get_entity_id(self):
        return self.activation_context.entity_id

    def request_fast_check(self, fast_check_id):
        self.fast_check_id = fast_check_id

    def get_fast_status(self):
        ret = self.fast_status_ready, self.fast_check_id
        if self.fast_status_ready:
            self.fast_status_ready = None
            self.fast_check_id = None
        return ret

    def event_disable(self):
        self.logger.info("event_disable (probably config cleared/plugin disabled): plugin: %s", self)
        try:
            self.config = None
            self._recreate_engine()
            self.set_full_status(PluginState.UNINITIALIZED)
        except Exception:
            self.set_full_status(PluginState.ERROR_UNKNOWN, sys.exc_info())

    def event_gather_measurements(self):
        self._execute_next_task()

    def event_set_configuration(self, config):
        self.logger.info(
            "event_set_configuration, plugin: %s config: %s",
            self,
            ruxit.config_utils.remove_sensitive_config_data(self.metadata, config)
        )
        self.config = config
        # this looks odd - are we only recreating engine when everything is fine?
        # no - the if statement is to because raising an error already recreates engine
        # so we don't need to do it again
        if PluginStateGroups.is_fine(self._state):
            self._recreate_engine()
        self._execute_next_task()

    def _execute_next_task(self):
        start_time = self.external_api.get_timestamp()
        self.last_measurements_timestamp = time.monotonic()
        self.last_wrapped_results = None
        try:
            self._engine.send(None)
            measurements, properties, events = self.results_builder.flush_result()
            self.last_wrapped_results = self._wrap_results(measurements, properties, events, self.external_api.get_timestamp())
            self._crash_count = 0
            self._executions_count += 1
        except Exception:
            self._handle_task_exception()
            raise
        finally:
            if self.fast_check_id:
                self.fast_status_ready = self.get_full_status()
            end_time = self.external_api.get_timestamp()
            self._register_stats(start_time, end_time, threading.current_thread().ident)

    def _handle_task_exception(self):
        self._crash_count += 1
        exception_info = sys.exc_info()
        self.set_full_status(
            self._exc_to_state.get(exception_info[0], PluginState.ERROR_UNKNOWN),
            exception_info
        )
        self._recreate_engine()

    def _crash_limit_exceeded(self):
        if self.plugin_info.is_in_development:
            return False
        return self._crash_count >= self._crash_limit

    def _recreate_engine(self):
        try:
            self._engine.close()
        except Exception:
            self.logger.info("Closing plugin_engine threw exception", exc_info=1)
        self._engine = engine_generator(self)

    def shutdown(self):
        return self._engine.close()

    def _register_stats(self, start_time, end_time, thread_id):
        cpu_info = self._get_cpu_stats()
        stats = ExecStat(start_time, end_time, thread_id, cpu_info)
        self._stats.append(stats)

    def get_execution_count(self):
        return self._executions_count

    def get_stats(self):
        if self._stats:
            return self._stats[-1]

    def _get_cpu_stats(self):
        return self.external_api.get_cpu_usage()

    def flush_results(self):
        last_wrapped_results, self.last_wrapped_results = self.last_wrapped_results, None
        return last_wrapped_results

    def select_id(self, **kwargs):
        return self.activation_context.select_id(**kwargs)

    def _wrap_results(self, measurements, properties, events, timestamp):
        self._selector_cache = {}
        return WrappedResults(
            measurements=self._wrap_measurements(measurements, timestamp),
            properties=self._wrap_properties(properties),
            events=self._wrap_events(events)
        )

    def _selector_resolve(self, selector):
        if selector not in self._selector_cache:
            self._selector_cache[selector] = self.entity_resolver.resolve(selector, plugin_engine=self)
        return self._selector_cache[selector]

    def _get_aggregation(self, key, metric_metadata, isV3):
            if isV3:
                return 1 # 1 means average "AVG"
            aggregation = metric_metadata.get("source", {"aggregation": "AVG"}).get("aggregation", "AVG")
            aggregation_type = AggregationTypes.__members__.get(aggregation.lower(), None)
            if aggregation_type:
                return aggregation_type.value
            else:
                self.logger.warn("Unrecognized aggregation type: %s for metric: %s", aggregation, key)
                return None

    def _validate_metric_dimensions(self, metric, metric_metadata, isState):
        if isState:
            metadata_timeseries = metric_metadata.get('statetimeseries', None)
        else:
            metadata_timeseries = metric_metadata.get('timeseries', None)
        if not metadata_timeseries:
            self.logger.warn("Unable to find timeseries metric metadata for metric: %s", metric.key)
            return False

        metadata_dimensions = metadata_timeseries.get('dimensions', None)
        if metadata_dimensions is None:
            if metric.dimensions:
                raise Exception("Dimension for metric '" + metric.key + "' provided but not expected.")
        else:
            received_dimensions = [key for key in metric.dimensions]
            if len(metadata_dimensions) != len(received_dimensions):
                raise Exception("Dimensions amount mismatch for metric '" + metric.key + "'. Expected: " +
                                str(len(metadata_dimensions)) + " Received: " + str(len(metric.dimensions)))
            if set(metadata_dimensions) != set(received_dimensions):
                raise Exception("Dimensions mismatch for metric '" + metric.key + "'. Expected: " +
                                str(metadata_dimensions) + " Received: " + str(received_dimensions))
        return True

    def _wrap_measurements(self, measurements, timestamp):
        if not isinstance(measurements, ruxit.api.data.PluginMeasurementList):
            raise TypeError(
                "PluginResults can only be an instance of ruxit.api.PluginMeasurementsList, got %s instead" % type(
                    measurements))

        if Firewall.is_custom_plugin_dir(self.plugin_info.directory):
            if measurements.length > self.results_builder.CUSTOM_PLUGIN_MEASUREMENTS_LIMIT:
                raise Exception("Number of measurements exceeded allowed threshold: " +
                                str(self.results_builder.CUSTOM_PLUGIN_MEASUREMENTS_LIMIT))

        wrapped_measurements = WrappedPluginMeasurementList(
            timestamp=measurements.timestamp or timestamp,
            measurements=[]
        )

        for metric in measurements.measurements:

            try:
                _, entity_id = self._selector_resolve(metric.entity_selector)
            except Exception:
                self.logger.info("Unable to select entity_id for %s", metric, exc_info=1)
                continue

            metric_value = metric.value
            isState = isinstance(metric, ruxit.api.data.PluginStateMetric)
            if isState:
                state_data = self.states_data.get (metric.key, None)
                if not state_data:
                    self.logger.warn("Unable to find state metric metadata for metric: %s", metric.key)
                    continue
                if isinstance(metric_value, str):
                    int_value = state_data.states.get(metric_value, None)
                    if int_value is None:
                        self.logger.warn("Unknown value for state metric (metric %s and value %s) %s", metric.key, metric_value, int_value)
                        self.logger.warn("Available states: %s", state_data.states)
                        continue
                    else:
                        metric_value = float(int_value)

            isV3 = (not isState) and isinstance(metric, ruxit.api.data.PluginMeasurementV3)
            isStatCounter = (not isState) and isinstance(metric, ruxit.api.data.PluginMeasurementStatCounter)


            if not isV3:
                metric_metadata = self.metadata_by_metric.get(metric.key, None)
                if not metric_metadata:
                    self.logger.warn("Unable to find metric metadata for metric: %s", metric.key)
                    continue

                if not self._validate_metric_dimensions(metric, metric_metadata, isState):
                    continue

                aggregation = self._get_aggregation(metric.key, metric_metadata, isV3)
                if not aggregation:
                    continue
            else:
                aggregation = self._get_aggregation(metric.key, None, isV3)

            wrapped_measurements.measurements.append(WrappedPluginMeasurement(
                monitoredEntityId=entity_id,
                tsIdentifier="%s:%s" % (self.plugin_info.reported_name, metric.key),
                dimensions=[Dimension(key=k, value=v) for k, v in metric.dimensions.items()],
                value=metric_value,
                aggregation=aggregation,
                isV3=isV3,
                isStatetimeseries=isState,
                isStatCounter=isStatCounter
            ))

        return wrapped_measurements

    def _wrap_properties(self, properties):
        properties_by_meid = collections.defaultdict(lambda: [])
        for prop in properties:
            try:
                entity_type, entity_id = self._selector_resolve(prop.entity_selector)
                entity = ruxit.api.selectors.MeId(metype=entity_type.value, meid=entity_id)
            except Exception:
                self.logger.info('Unable to set entity_id for %s', prop, exc_info=1)
                continue
            properties_by_meid[entity].append(CustomPropertyProtoWrapper(
                key=prop.key, value=prop.value, me_attribute=prop.me_attribute.value))
        return properties_by_meid

    def _wrap_events(self, events):

        if Firewall.is_custom_plugin_dir(self.plugin_info.directory):
            if len(events) > self.results_builder.CUSTOM_PLUGIN_EVENTS_LIMIT:
                raise Exception("Number of events exceeded allowed threshold: " +
                                str(self.results_builder.CUSTOM_PLUGIN_EVENTS_LIMIT))

        wrapped_events = []
        for event in events:
            try:
                entity_type, entity_id = self._selector_resolve(event.entity_selector)
                wrapped_event = WrappedEvent(type=event.type,
                                             event_id=event.event_id,
                                             entity_id=entity_id,
                                             me_type=entity_type.value if entity_type else None,
                                             event_metadata=[])
                for event_metadata in event.metadata:
                    wrapped_event.event_metadata.append(WrappedEventMetadata(key=event_metadata.key,
                                                                             value=event_metadata.value,
                                                                             is_boolean=event_metadata.is_boolean,
                                                                             is_float=event_metadata.is_float,
                                                                             is_int=event_metadata.is_int,
                                                                             is_custom_properties=event_metadata.is_custom_properties))
                wrapped_events.append(wrapped_event)
            except Exception:
                self.logger.info('Unable to set entity_id for %s', event, exc_info=1)
                continue
        return wrapped_events

    def generate_plugin_args(self):
        return {
            'results_builder': self.results_builder,
            'json_config': self.metadata,
            'plugin_info': self.plugin_info,
            'associated_entity': self.activation_context.value,
            'activation_context': self.activation_context,
            'process_snapshot': self.entity_resolver.get_snapshot(),
            'entity_resolver': self.entity_resolver,
            'logger': self.logger
        }

    def __repr__(self):
        return "<PluginEngine, meta_name:%s id:%s>" % (self.metadata["name"], hex(id(self)))


def engine_generator(plugin_engine_instance):
    plugin_module = importlib.import_module(plugin_engine_instance.metadata["source"]["package"])
    plugin_class = getattr(plugin_module, plugin_engine_instance.metadata["source"]["className"])
    plugin_config = copy.deepcopy(plugin_engine_instance.config)
    # additional parameters can be passed upon plugin creation here - e.g api_object

    plugin_args = plugin_engine_instance.generate_plugin_args()
    plugin_args['config'] = plugin_config

    plugin_instance = plugin_class(**plugin_args)
    plugin_engine_instance._instance = plugin_instance
    try:
        while True:
            plugin_args['process_snapshot'] = plugin_engine_instance.entity_resolver.get_snapshot()
            # state handling based on return values can be added here
            try:
                plugin_instance._query_internal(**plugin_args)
                if plugin_engine_instance.execution_timeout:
                    plugin_status = PluginFullStatus(
                        pluginName=plugin_engine_instance.plugin_info.reported_name,
                        pluginVersion=plugin_engine_instance.metadata['version'],
                        state=PluginState.ERROR_UNKNOWN.value,
                        description='Plugin execution timeout',
                        stacktrace='No stack trace',
                        monitoredEntityId=plugin_engine_instance.get_entity_id()
                    )
                    plugin_engine_instance.full_status = plugin_status
                else:
                    plugin_engine_instance.set_full_status(PluginState.OK)
                yield
            except ruxit.api.exceptions.NothingToReportException:
                exception_info = sys.exc_info()
                plugin_engine_instance.set_full_status(PluginState.NOTHING_TO_REPORT, exception_info)
                yield
    finally:
        plugin_instance.close()



