import collections
import time
from typing import List
from ruxit.remote.remote_plugin_engine import RemotePluginEngine

RemoteTopologyInfo = collections.namedtuple(
    "RemoteTopologyInfo",
    ["contentType", "timestamp", "customDeviceGroups"]
)
CustomDeviceGroup = collections.namedtuple(
    "CustomDeviceGroup",
    ["groupEntityId", "groupName", "customDevices", "technologies", "reportingPluginConfigId", "endpoints"]
)
CustomDevice = collections.namedtuple(
    "CustomDevice",
    ["entityId", "name", "stateTransitions", "technologies", "endpoints"]
)

Endpoint = collections.namedtuple(
    "Endpoint",
    ["ips", "dnsNames", "port"]
)

class PluginCustomDeviceReporter:
    '''
    This class is a bridge to the native code that's used to report the topology information.
    '''
    def __init__(self, external_api):
        self._external_api = external_api
        self._last_reported_devices = {}
        self._DEVICES_LIMIT = 500
        self._GROUPS_LIMIT = 50

    @property
    def _devices_limit(self):
        return self._external_api.get_int_debug_flag("debugPluginAgentDevicesLimitNative", self._DEVICES_LIMIT)

    @property
    def _groups_limit(self):
        return self._external_api.get_int_debug_flag("debugPluginAgentGroupsLimitNative", self._GROUPS_LIMIT)


    def report_devices(self, engine: RemotePluginEngine):
        '''
        Extracts the topology information from the passed engines.

        Args:
            engines: A list of remote plugin engines in the agent.
        '''
        groups = []

        # gather all topology groups from all plugins
        logger = engine.get_logger()

        if not engine.topology_builder:
            return

        groups_from_topology, config_id = engine.flush_topology()
        total_devices_no = 0

        for (group_id, group) in groups_from_topology.items():
            # gather all nodes from one plugin
            devices = []
            for node_name, node in group.get_elements().items():
                endpoints = []

                # gather all endpoints from one node
                for endpoint in node.endpoints:
                    ip, port, dns_names = endpoint
                    endpoints.append(Endpoint([ip], dns_names, port))

                if total_devices_no >= self._devices_limit:
                    raise Exception("Number of devices exceeded allowed threshold: " + str(self._devices_limit))
                else:
                    devices.append(CustomDevice(node.id, node.name, ["EXPLICIT_STATE_MONITORED"], [node.technology], endpoints))
                    total_devices_no = total_devices_no +1

            group_endpoints = []
            if len(groups) >= self._groups_limit:
                raise Exception("Number of groups exceeded allowed threshold: " + str(self._groups_limit))
            else:
                groups.append(CustomDeviceGroup(group.id, group.name, devices, [group.technology], config_id, group_endpoints))

        timestamp = int(time.time())*1000
        topology_info = RemoteTopologyInfo("REMOTE_PLUGINS_TOPOLOGY_INFO", timestamp, groups)
        logger.debug("Reporting topology %s: %s", engine, topology_info)

        self._external_api.report_topology(topology_info)

