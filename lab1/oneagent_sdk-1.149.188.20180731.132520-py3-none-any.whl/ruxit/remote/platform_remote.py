import collections
from typing import List, Any
from logging import getLogger
import json
from ruxit.platform.platform_api import EntityResolverIfc
from ruxit.platform.platform_api import PlatformAPI, SelectedPlugins, PluginConfig
from ruxit.package_utils.plugin_updater import PluginInfo
from ruxit.plugin_state_machine import PluginEngine
from ruxit.remote.support_alert_creator import SupportAlertCreator
from ruxit.select_plugins import BaseActivationContext, selectors
import ruxit.plugin_custom_device_reporter
from ruxit.remote.remote_plugin_engine import RemotePluginEngine
from ruxit.plugin_status_reporter import PluginFullStatus, PluginState
import sys

PluginInstanceConfig = collections.namedtuple("PluginInstanceConfig", ["instanceId", "properties", "fastId"])


class PluginConfigInfo:
    def __init__(self, plugin_name, config_id, plugin_instance_config, fast_id, fast_checked, enabled, is_new):
        self._plugin_name = plugin_name
        self._config_id = config_id
        self._plugin_instance_config = plugin_instance_config
        self._fast_id = fast_id
        self.fast_checked = fast_checked
        self._enabled = enabled
        self.is_new = is_new
        pass

    @property
    def plugin_name(self):
        return self._plugin_name

    @property
    def config_id(self):
        return self._config_id

    @property
    def plugin_instance_config(self):
        return self._plugin_instance_config

    @property
    def fast_id(self):
        return self._fast_id

    @property
    def enabled(self):
        return self._enabled


class RemoteActivationContext(BaseActivationContext):
    def __init__(self, config_id, properties):
        self.entity_id = config_id
        self.meid = (selectors.EntityType.CUSTOM_DEVICE_GROUP, self.entity_id)
        self.value = config_id
        self.properties = properties


class RemoteEntityResolver(EntityResolverIfc):
    def get_snapshot(self):
        return None

    def resolve(self, selector, **kwargs):
        return selector.select_id(
            process_snapshot=None,
            snapshot_by_process_type=collections.defaultdict(list),
            snapshot_by_technology=collections.defaultdict(list),
            docker_entity_map={},
            **kwargs
        )


class RemoteAPI(PlatformAPI):
    def __init__(self, external_api):
        self._external_api = external_api
        self._latest_plugin_configs = {}  # It stores the list of PluginConfigInfo taken from Remote Plugin Agent
        self._plugin_dev_global_logger = getLogger("plugin_development.global")
        self._plugin_topology_reporter = ruxit.plugin_custom_device_reporter.PluginCustomDeviceReporter(
            self._external_api)
        self._entity_resolver = RemoteEntityResolver()
        self.updated = False

    @property
    def external_api(self):
        return self._external_api

    @property
    def entity_resolver(self):
        return self._entity_resolver

    def _update_latest_configs(self):
        try:
            configs_raw = self._external_api.get_latest_configs()
            # self._plugin_dev_global_logger.info("Update latest configs raw: %s" % configs_raw)
        except:
            self._plugin_dev_global_logger.exception("Unable to get latest configs")
            return

        configs = {}
        for plugin_name, plugin_config_info in configs_raw.items():
            for config_instance in plugin_config_info.pluginConfigProperties:
                try:
                    instance = PluginInstanceConfig(instanceId=config_instance[0],
                                                    properties=config_instance[1],
                                                    fastId=config_instance[2])
                    plugin_json = json.loads(instance.properties)
                    all_properties = plugin_json.get('properties')

                    configs[instance.instanceId] = PluginConfigInfo(
                        plugin_name=plugin_name,
                        config_id=instance.instanceId,
                        plugin_instance_config=all_properties,
                        fast_id=instance.fastId,
                        fast_checked=False,
                        enabled=plugin_config_info.pluginEnabled,
                        is_new=False
                    )
                except Exception:
                    self._plugin_dev_global_logger.exception("Unable to parse config for plugin: %s" % plugin_name)
        config_changed = False
        contains_fast_config = False
        # Mark the changed configs with an update flag
        for (config_id, new_config) in configs.items():
            contains_fast_config |= config_id == 0

            old_corresponding_config = self._latest_plugin_configs.get(config_id, None)

            # compare two configs and mark them for update
            self._plugin_dev_global_logger.info(new_config.plugin_instance_config)
            if old_corresponding_config:
                new_config.fast_checked = old_corresponding_config.fast_checked
                self._plugin_dev_global_logger.info(old_corresponding_config.plugin_instance_config)
            else:
                self._plugin_dev_global_logger.info("no old config present")

            if not old_corresponding_config or new_config.plugin_instance_config != old_corresponding_config.plugin_instance_config:
                self._plugin_dev_global_logger.info("Fresh config received for plugin %s" % new_config.plugin_name)
                new_config.is_new = True
                config_changed = True

        old_fast_config = self._latest_plugin_configs.get(0, None);
        if (not contains_fast_config) and (old_fast_config):
            config_changed = True

        self._latest_plugin_configs = configs

        return config_changed

    def data_update(self) -> bool:
        return self._update_latest_configs()

        if self.updated:
            return False
        self.updated = True

        self._latest_plugin_configs = {}

        props = {'group_name': "LTM-11",
                 'tech': "F5_LTM",
                 'some_endpoint_ip': "1.2.3.4"
                 }

        pc = PluginConfig(props, 0, True)

        self._latest_plugin_configs[11] = PluginConfigInfo(
            plugin_name="custom.remote.python.wtf2",
            config_id=11,
            plugin_instance_config=props,
            fast_id=0,
            fast_checked=False,
            enabled=True,
            is_new=True
        )

        return True

    @staticmethod
    def _get_plugin_info_by_name(plugin_metadata: List[PluginInfo], name: str) -> PluginInfo:
        return next((x for x in plugin_metadata if x.name == name), None)

    def select_plugins(self, plugin_engines: List[RemotePluginEngine],
                       plugin_metadata: List[PluginInfo]) -> SelectedPlugins:
        to_activate = []
        to_deactivate = []

        # for every engine, if it's not present in the config
        for plugin_engine in plugin_engines:
            cfg = [config_id for (config_id, cfg_instance) in self._latest_plugin_configs.items() if
                   plugin_engine.config_id == config_id]
            if not cfg or self._fast_check_should_restart(cfg):
                self._plugin_dev_global_logger.debug("deactivating" + str(plugin_engine.config_id))
                to_deactivate.append(plugin_engine)

        for (config_id, plugin_config_instance) in self._latest_plugin_configs.items():
            plugin_name = plugin_config_instance.plugin_name

            # Only pass configs that are updated
            if not plugin_config_instance.is_new:
                self._plugin_dev_global_logger.debug("Ignoring existing instance of %s" % plugin_name)
                continue

            plugin_info = self._get_plugin_info_by_name(plugin_metadata, plugin_name)

            if not plugin_info:
                self._plugin_dev_global_logger.warn("No metadata available for plugin %s" % plugin_name)
                continue

            config_id = plugin_config_instance.config_id

            self._plugin_dev_global_logger.debug("activating " + str(config_id))
            to_activate.append(
                (RemoteActivationContext(config_id, plugin_config_instance.plugin_instance_config),
                 plugin_info
                 )
            )

        return SelectedPlugins(to_activate, to_deactivate)

    def _fast_check_should_restart(self, cfg) -> bool:
        print(str(self._latest_plugin_configs[cfg[0]]))
        return self._latest_plugin_configs[cfg[0]].fast_id or self._latest_plugin_configs[cfg[0]].fast_checked

    def get_plugin_config(self, plugin_engine: RemotePluginEngine, plugin_metadata: List[PluginInfo]) -> PluginConfig:
        config_id = plugin_engine.get_entity_id()
        cfg = self._latest_plugin_configs.get(config_id, None)

        if cfg:
            if cfg.fast_id:
                cfg.fast_checked = True
                return PluginConfig(cfg.plugin_instance_config, cfg.fast_id, True)
            else:
                return PluginConfig(cfg.plugin_instance_config, 0, True)
        else:
            return PluginConfig(None, 0, False)

    def additional_report_step(self, plugin_engine: RemotePluginEngine) -> None:
        try:
            self._plugin_topology_reporter.report_devices(plugin_engine)
        except Exception as error:
            exception_info = sys.exc_info()
            plugin_engine.set_full_status(PluginState.ERROR_UNKNOWN, exception_info)
            # clear up results and topology:
            plugin_engine.results_builder.reset_result()
            plugin_engine.topology_builder._groups = {}
        return

    def create_engine(self, plugin_info: PluginInfo, activation_context) -> Any:
        return RemotePluginEngine(
            external_api=self._external_api,
            entity_resolver=self._entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context,
        )

    def get_support_alert_creator(self) -> SupportAlertCreator:
        # return self._external_api.get_int_debug_flag("debugPluginAgentDevicesLimitNative", self._DEVICES_LIMIT)
        return SupportAlertCreator(
            self._external_api.get_remote_plugin_process_metrics,
            [
                SupportAlertCreator.OBSERVED_EVENT(lambda: self._external_api.get_int_debug_flag(
                    "debugCpuLimit", SupportAlertCreator.DEFAULT_CPU_LIMIT),
                                                   "cpu_time_real",
                                                   self._external_api.create_support_alert_high_cpu_usage
                                                   ),
                SupportAlertCreator.OBSERVED_EVENT(lambda: self._external_api.get_int_debug_flag(
                    "debugMemoryLimit", SupportAlertCreator.DEFAULT_MEMORY_LIMIT),
                                                   "working_set_size",
                                                   self._external_api.create_support_alert_high_memory_usage,
                                                   )
            ]
        )
