from ruxit.api.topology_builder import TopologyBuilder, Topology
from ruxit.plugin_state_machine import PluginEngine


class RemotePluginEngine(PluginEngine):

    def __init__(self, *, external_api, entity_resolver, plugin_info, activation_context):
        super().__init__(
            external_api=external_api,
            entity_resolver=entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context
        )

        #def __init__(self, *args, **kwargs):
        #    super().__init__(*args, **kwargs)

        print(self.activation_context)
        self.config_id = activation_context.value
        #self.config = activation_context.config
        tenant_id = self.external_api.get_working_tenant()
        self.topology_builder = TopologyBuilder(self.config_id, plugin_info.name, tenant_id, plugin_info.technologies, self.results_builder)

    def flush_topology(self) -> Topology:
        """
        Polls the topology from the topology builder
        Return:
            Topology data.
        """
        topology = self.topology_builder.flush_result() if self.topology_builder else None
        return topology

    def generate_plugin_args(self):
        plugin_args = super().generate_plugin_args()
        plugin_args['topology_builder'] = self.topology_builder
        return plugin_args

    def __repr__(self):
        return "<RemotePluginEngine, meta_name:%s id:%s>" % (self.metadata["name"], hex(id(self)))