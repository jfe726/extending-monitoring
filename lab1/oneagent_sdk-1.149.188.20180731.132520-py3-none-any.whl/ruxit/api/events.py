"""
Event reporting API for plugins.
"""
from time import time
from builtins import int
from hashlib import md5
from enum import IntEnum
import ruxit.api.selectors


class EventType(IntEnum):
    HOST_VM_STARTED = 57
    HOST_VM_SHUTDOWN = 58
    VM_MOTION = 59
    VM_LAUNCH_FAILED = 65

    PERFORMANCE_EVENT = 67
    ERROR_EVENT = 68
    AVAILABILITY_EVENT = 69
    RESOURCE_CONTENTION_EVENT = 70
    CUSTOM_INFO = 71
    CUSTOM_DEPLOYMENT = 72
    CUSTOM_ANNOTATION = 73


class EventMetadataKey(IntEnum):
    VM_DESTINATION_HOST_ID = 155
    VM_SOURCE_HOST_ID = 156
    HOST_AFFECTED_VM_ID = 157
    PROJECT_ID = 158
    OPENSTACK_REASON = 162

    CUSTOM_DESCRIPTION = 163
    CUSTOM_TITLE = 164
    CUSTOM_PROPERTIES = 165
    CUSTOM_ANNOTATION_TYPE = 166
    CUSTOM_SOURCE = 167
    CUSTOM_PROJECT = 168
    CUSTOM_VERSION = 169
    CUSTOM_CI_BACK_LINK = 170
    CUSTOM_REMEDIATION_ACTION_LINK = 171
    CUSTOM_DEPLOYMENT_NAME = 172


# event methadata - it's non-mutable object
class EventMetadata:

    def __init__(self, key: int, value):
        self._key = key
        self._value = value

    @property
    def key(self):
        return self._key

    @property
    def is_boolean(self):
        return type(self._value) is bool

    @property
    def is_float(self):
        return type(self._value) is float

    @property
    def is_int(self):
        return type(self._value) is int

    @property
    def is_custom_properties(self):
        return type(self._value) is dict

    @property
    def is_not_set(self):
        return self._value is None

    @property
    def value(self):
        if self.is_boolean or self.is_float or self.is_int or self.is_custom_properties or self.is_not_set:
            return self._value
        else:
            return str(self._value)

    def __repr__(self):
        return "EventMetadata(key=%s,value=%s)" % (self.key, self.value)


# event is non-mutable object
# contenttype is default from protobuf message
# eventId is automatic
# agentId, timestamp, smin, smax are set by OS Agent
# required: type, entity_id
class Event:

    __event_id_generator = 1

    def __init__(self,
                 type: int,
                 entity_selector: ruxit.api.selectors.FromPluginSelector(),
                 metadata: list = []
                 ):
        self._type = type
        self._entity_selector = entity_selector

        self._event_id = self.__get_event_id(type)
        self._metadata = metadata

    @staticmethod
    def __get_event_id(type):
        m = md5()
        byteorder = "little"
        m.update(type.to_bytes(64, byteorder))
        m.update(round(time()*100).to_bytes(64, byteorder))
        m.update(Event.__event_id_generator.to_bytes(64, byteorder))
        Event.__event_id_generator += 1
        bytes = m.digest()
        first_part = 0
        second_part = 0
        for index in range(8):
            first_part = first_part << 8;
            first_part |= bytes[index];
            second_part = second_part << 8;
            second_part |= bytes[index+8];
        return first_part ^ second_part

    @property
    def type(self):
        return self._type

    @property
    def event_id(self):
        return self._event_id

    @property
    def entity_selector(self):
        return self._entity_selector

    @property
    def metadata(self):
        return frozenset(self._metadata)
