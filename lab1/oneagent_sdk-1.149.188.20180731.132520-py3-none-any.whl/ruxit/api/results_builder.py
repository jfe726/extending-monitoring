"""
Data reporting API for plugins.
"""
import copy
from ruxit.api.data import BaseMetric, PluginMeasurementList, PluginMeasurement, PluginProperty, PluginMeasurementStatCounter
from ruxit.api.selectors import ExplicitPgiSelector, EntityType, FromPluginSelector
from ruxit.utils.firewall import InternalAPI
from ruxit.api.events import Event, EventMetadataKey, EventType, EventMetadata
import time
from typing import Dict


class ResultsBuilder:
    """
    Class storing data gathered by plugins. An instance of this class is associated with each plugin instance.

    The builder can store intermittent results and perform calculations on them when they need to be sent away. Those
    include computing the difference between subsequent measurement, providing per second rates etc.

    Measurements can be passed in the form of manually created :class:`~ruxit.api.data.PluginMeasurement` objects (via
    add_*_result methods), or via absolute/relative/per_second methods which construct the measurement instances
    themselves.
    """

    _CUSTOM_PLUGIN_MEASUREMENTS_LIMIT = 1000
    _CUSTOM_PLUGIN_EVENTS_LIMIT = 100

    def __init__(self, logger, external_api):
        self.logger = logger
        # external_api for debug flags only
        self.external_api = external_api
        self.old_relative_results = {}
        self.old_per_second_results = {}
        self.__reset_result()

    def __reset_result(self):
        self.relative_results = {}
        self.per_second_results = {}
        self.absolute_results = []
        self.events = []
        self.plugin_properties = []
        self._timestamp = None

    # call reset_result in case of an exception to clear up incomplete results
    def reset_result(self):
        self.__reset_result()
        self.old_relative_results = {}
        self.old_per_second_results = {}

    @staticmethod
    def _pm_to_key(pm):
        return pm.key, tuple(pm.dimensions.items()), pm.entity_selector

    @staticmethod
    def _check_measurement_type(plugin_measurement):
        if not isinstance(plugin_measurement, BaseMetric):
            raise TypeError("Each measurement should be an instance of BaseMetric, got %s instead" % type(plugin_measurement))

    @property
    def CUSTOM_PLUGIN_MEASUREMENTS_LIMIT(self):
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentMeasurementsLimitNative", self._CUSTOM_PLUGIN_MEASUREMENTS_LIMIT)

    @property
    def CUSTOM_PLUGIN_EVENTS_LIMIT(self):
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentEventsLimitNative", self._CUSTOM_PLUGIN_EVENTS_LIMIT)

    def _createpm(self, **kwargs):
        if 'entity_id' in kwargs:
            if 'entity_selector' in kwargs:
                raise ValueError("entity_id and entity_selector are mutually exclusive options")
            entity_id = kwargs.pop('entity_id')
            if 'entity_type' in kwargs:
                if not isinstance(kwargs.get('entity_type'), EntityType):
                    raise ValueError("entity_type must be instance of EntityType")
                entity_type = kwargs.pop('entity_type')
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id, me_type=entity_type)
            else:
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id)
        return PluginMeasurement(**kwargs)

    def add_relative_result(self, plugin_measurement):
        """
        Adds a relative result. Use for metrics that increase monotonically (counters etc.) After gathering 2nd result,
        difference between current and previous one will be sent to the server, if it is non-negative. If there is a
        negative difference between measurements - nothing is sent.

        Args:
            plugin_measurement(PluginMeasurement): measurement
        """
        if isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_relative_result doesn't support measurement of type PluginMeasurementStatCounter." )
        self._check_measurement_type(plugin_measurement)
        self.relative_results[self._pm_to_key(plugin_measurement)] = plugin_measurement

    def add_absolute_result(self, plugin_measurement):
        """
        Adds an absolute results. Absolute results are sent unmodified - no additional calculations are performed.

        Args:
            plugin_measurement(PluginMeasurement): measurement

        """
        self._check_measurement_type(plugin_measurement)
        self.absolute_results.append(plugin_measurement)

    def add_absolute_stat_counter_result(self, plugin_measurement):
        """
        DT_IGNORE - because this isn't meant to be an advertised method of sending metrics.
        Adds an absolute PluginMeasurementStatCounter results. Absolute results are sent unmodified - no additional calculations are performed.

        Args:
            plugin_measurement(PluginMeasurementStatCounter): measurement

        """
        if not isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_absolute_stat_counter_result is designated for measurement of type PluginMeasurementStatCounter only." )
        self.add_absolute_result(plugin_measurement)


    def add_per_second_result(self, plugin_measurement):
        """
        Adds per second result. Use for metrics that increase monotonically (counters etc.) After gathering 2nd result,
        difference between current and previous one will be sent to the server, if it is non-negative. It will be
        divided by the time difference between measurements in seconds - resulting in a per second rate. If there is a
        negative difference between measurements - nothing is sent.

        Args:
            plugin_measurement(PluginMeasurement): measurement

        """
        if isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_per_second_result doesn't support measurement of type PluginMeasurementStatCounter." )
        self._check_measurement_type(plugin_measurement)
        self.per_second_results[self._pm_to_key(plugin_measurement)] = (plugin_measurement, time.monotonic())

    def absolute(self, **kwargs):
        """
        Adds absolute result. PluginMeasurement object is constructed implicitly in the method. Keyword arguments
        correspond to :class:`~ruxit.api.data.PluginMeasurement` class keyword with the addition of:

        Args:
            entity_id: value of entity id.
            entity_type (EntityType): type of entity. Default: :class:`ruxit.api.selectors.EntityType.PROCESS_GROUP_INSTANCE`
        """
        _pm = self._createpm(**kwargs)
        self.add_absolute_result(_pm)

    @InternalAPI
    def add_event(self, event):
        """
        Adds a event
        
        Args:
            event(Event): event
        """
        self.events.append(event)

    def relative(self, **kwargs):
        """
        Adds relative result, with PluginMeasurement object constructed implicitly. Accepts arguments identical to
        :meth:`~ruxit.api.results_builder.ResultsBuilder.absolute`

        """
        _pm = self._createpm(**kwargs)
        self.add_relative_result(_pm)

    def per_second(self, **kwargs):
        """
        Adds per second result, with PluginMeasurement object constructed implicitly. Accepts arguments identical to
        :meth:`~ruxit.api.results_builder.ResultsBuilder.absolute`

        """
        _pm = self._createpm(**kwargs)
        self.add_per_second_result(_pm)

    def add_property(self, plugin_property):
        """
        Adds a property to the results
        Args:
            plugin_property (PluginProperty): the property.
        """
        if not isinstance(plugin_property, PluginProperty):
            raise TypeError("Each property should be an instance of PluginProperty, got %s instead" % type(plugin_property))
        self.plugin_properties.append(plugin_property)

    def set_timestamp(self, timestamp):
        """
        Allows explicit setting of timestamp for all gathered measurements.

        Args:
            timestamp: timestamp
        """
        self._timestamp = timestamp

    def flush_result(self):
        """
        Prepares gathered data to be sent out to the server. Computes values for relative and per_second results.

        Returns:
            measurements and properties gathered during the most recent data collection period.
        """
        measurements = PluginMeasurementList(measurements=[], timestamp=self._timestamp)

        for relative_result_key, relative_metric in self.relative_results.items():
            old_relative_metric = self.old_relative_results.get(relative_result_key, None)
            if old_relative_metric is not None:
                delta_metric = copy.copy (relative_metric)
                value_delta = relative_metric.value - old_relative_metric.value
                if value_delta < 0:
                    self.logger.info(
                        "Value decrease in relative result, skip reporting, new value %s, old value %s",
                        relative_metric.value,
                        old_relative_metric.value
                    )
                    continue
                delta_metric.value = value_delta
                measurements.measurements.append(delta_metric)

        for per_second_result_key, per_second_result in self.per_second_results.items():
            old_per_second_result = self.old_per_second_results.get(per_second_result_key, None)
            if old_per_second_result is not None:
                value_per_second = (per_second_result[0].value-old_per_second_result[0].value)/(per_second_result[1]-old_per_second_result[1])
                if value_per_second < 0:
                    self.logger.info(
                        "Per second result less than 0, skip reporting, new value %s, old value %s",
                        per_second_result,
                        old_per_second_result
                    )
                    continue
                per_second = copy.copy (per_second_result[0])
                per_second.value = value_per_second
                measurements.measurements.append(per_second)

        measurements.measurements.extend(self.absolute_results)

        self.old_relative_results = self.relative_results
        self.old_per_second_results = self.per_second_results
        properties = self.plugin_properties
        events = self.events
        self.__reset_result()
        return measurements, properties, events

    def report_performance_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {},
                                 entity_selector=FromPluginSelector()):
        self.events.append(self._create_event(type=EventType.PERFORMANCE_EVENT, description=description, title=title,
                                              properties=properties, entity_selector=entity_selector))

    def report_error_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {},
                           entity_selector=FromPluginSelector()):
        self.events.append(self._create_event(type=EventType.ERROR_EVENT, description=description, title=title,
                                              properties=properties, entity_selector=entity_selector))

    def report_availability_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {},
                                  entity_selector=FromPluginSelector()):
        self.events.append(self._create_event(type=EventType.AVAILABILITY_EVENT, description=description, title=title,
                                              properties=properties, entity_selector=entity_selector))

    def report_resource_contention_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {},
                                         entity_selector=FromPluginSelector()):
        self.events.append(self._create_event(type=EventType.RESOURCE_CONTENTION_EVENT, description=description, title=title,
                                              properties=properties, entity_selector=entity_selector))

    def report_custom_info_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {},
                                 entity_selector=FromPluginSelector()):
        self.events.append(self._create_event(type=EventType.CUSTOM_INFO, description=description, title=title,
                                              properties=properties, entity_selector=entity_selector))

    def report_custom_deployment_event(self,
                                       source: str = None,
                                       project: str = None,
                                       version: str = None,
                                       ci_link: str = None,
                                       remediation_action_link: str = None,
                                       deployment_name: str = None,
                                       properties: Dict[str, str] = {},
                                       entity_selector=FromPluginSelector()):
        self.events.append(Event(type=EventType.CUSTOM_DEPLOYMENT,
                                 entity_selector=entity_selector,
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_SOURCE, value=source),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROJECT, value=project),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_VERSION, value=version),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_CI_BACK_LINK, value=ci_link),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_REMEDIATION_ACTION_LINK, value=remediation_action_link),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DEPLOYMENT_NAME, value=deployment_name),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)
                                 ]))

    def report_custom_annotation_event(self,
                                       description: str = None,
                                       annotation_type: str = None,
                                       source: str = None,
                                       properties: Dict[str, str] = {},
                                       entity_selector=FromPluginSelector()):
        self.events.append(Event(type=EventType.CUSTOM_ANNOTATION,
                                 entity_selector=entity_selector,
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DESCRIPTION, value=description),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_ANNOTATION_TYPE, value=annotation_type),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_SOURCE, value=source),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)
                                 ]))

    def _create_event(self, **kwargs):
        return Event(type=kwargs['type'],
                                 entity_selector=kwargs['entity_selector'],
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DESCRIPTION, value=kwargs['description']),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_TITLE, value=kwargs['title']),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=kwargs['properties'])])



