"""
Structures for holding data gathered by plugins. They enforce types so that a plugin cannot accidentally report
a number as a string.
"""

from enum import Enum, IntEnum, unique
import typing
import ruxit.api.selectors
from ruxit.utils.firewall import InternalAPI_ext, Firewall

class StatCounterDataPoint:
    """ DT_IGNORE """
    def __init__(self, min: float, max: float, sum: float, count: int):
        self._min = min
        self._max = max
        self._sum = sum
        self._count = count

    @property
    def min(self):
        return self._min

    @property
    def max(self):
        return self._max

    @property
    def sum(self):
        return self._sum

    @property
    def count(self):
        return self._count


class BaseMetric:
    def __init__(self, key, value, dimensions: typing.Dict[str, str] = None,
                 entity_selector=ruxit.api.selectors.FromPluginSelector()):
        self.key = key
        self.value = value
        self.dimensions = dimensions
        self.entity_selector = entity_selector

    @property
    def key(self):
        """
        Key of the measurement. Must be a string.
        """
        return self._key

    @property
    def value(self):
        """
        Value of the measurement. Must be convertible to float.
        """
        return self._value


    @property
    def dimensions(self):
        """
        Dimensions of the measurement. A Dictionary with string keys and string values.
        """
        return self._dimensions

    @dimensions.setter
    def dimensions(self, dimensions: typing.Dict[str, str]):
        self._dimensions = {}
        if dimensions:
            for key, value in dimensions.items():
                if isinstance(key, str) is False or isinstance(value, str) is False:
                    raise TypeError("Each dimensions key, and value must be unicode object, got %s and %s instead" % (type(key), type(value)))
            self._dimensions = dimensions

    def __repr__(self):
        return "%s(key=%s,value=%s,dimensions=%s,selector=%s)" % (type(self).__name__, self.key, self.value, self.dimensions, self.entity_selector)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return self.__dict__ == other.__dict__
        return NotImplemented

    
class PluginMeasurement(BaseMetric):
    """
    Single plugin measurement.

    Use of this class is optional. :class:`~ruxit.api.results_builder.ResultsBuilder` exposes methods that handles this
    type directly and those that abstract them away.
    """
    def __init__(self, key: str, value: float, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: float):
        if not isinstance(value, float):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value


class PluginMeasurementStatCounter(BaseMetric):
    """
    DT_IGNORE
    PluginMeasurementStatCounter object allows sending min, max, sum and counter values instead of single plugin measurement.

    Use of this class is optional. :class:`~ruxit.api.results_builder.ResultsBuilder` exposes `add_absolute_stat_counter_result` method to send PluginMeasurementStatCounter.
    """
    def __init__(self, key: str, value: StatCounterDataPoint, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: StatCounterDataPoint):
        if not isinstance(value, StatCounterDataPoint):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value


class PluginStateMetric(BaseMetric):
    """
    State measurement.

    States are string described in plugin json as statetimeseries
    """
    def __init__(self, key: str, value: str, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value):
        if isinstance(value, Enum):
            self._value = value.value
        elif not isinstance(value, str):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value

class PluginMeasurementV3(BaseMetric):
    """
    Not allowed for Custom Plugin
    """
    @InternalAPI_ext(exc_message="PluginMeasurementV3 is not allowed for Custom Plugin")
    def __init__(self, key: int, value: float, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: int):
        if not isinstance(key, int):
            raise TypeError("key must be an integer, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: float):
        if not isinstance(value, float):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value
            

@unique
class MEAttribute(IntEnum):
    """
    Enumerates types of properties to report.
    """
    INTERNAL_DEBUG_PROPERTY = 1
    DOCKER_CONTAINER_PROPS = 2
    PROCESS_GROUP_TECHS = 3
    CONTRIBUTED_NAME = 4
    CUSTOM_PG_METADATA = 5
    CUSTOM_DEVICE_METADATA = 6
	
class PluginProperty:
    """
    A text property a plugin can gather.
    """
    __allowed_prop = frozenset([MEAttribute.PROCESS_GROUP_TECHS, MEAttribute.CONTRIBUTED_NAME, MEAttribute.CUSTOM_PG_METADATA])

    def __init__(self, key=None, value=None, entity_selector=ruxit.api.selectors.FromPluginSelector(),
                 me_attribute=MEAttribute.INTERNAL_DEBUG_PROPERTY):
        """
        Args:

            key (string): property key
            value (string): property value
            entity_selector: plugin's entity selector :class:`~ruxit.api.selectors.FromPluginSelector` by default
            me_attribute(MEAttribute): property type
        """
        self.key = key
        self.value = value
        self.entity_selector = entity_selector
        if me_attribute not in PluginProperty.__allowed_prop and not Firewall.is_allowed_call():
            raise Exception(str(me_attribute) + " property type is not allowed for custom plugins")
        self.me_attribute = me_attribute

    @property
    def key(self):
        """
        Key of property.
        """
        return self._key

    @key.setter
    def key(self, key):
        if key is not None and not isinstance(key, str):
            raise TypeError("key must be an unicode object or None type, got, %s instead" % type(key))
        self._key = key

    @property
    def value(self):
        """
        Value of property
        """
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, str):
            raise TypeError("value must be an unicode object or None type, got, %s instead" % type(value))
        self._value = value

    @property
    def me_attribute(self):
        """
        Property type
        """
        return self._me_attribute

    @me_attribute.setter
    def me_attribute(self, me_attribute):
        if not isinstance(me_attribute, MEAttribute):
            raise TypeError("value must be an MEAttribute object, got, %s instead" % type(me_attribute))
        self._me_attribute = me_attribute

    def __repr__(self):
        return "PluginProperty(key=%s,value=%s,selector=%s,me_attribute=%s)" % (
            self.key, self.value, self.entity_selector, self.me_attribute)


class PluginMeasurementList:
    """
    Collection of PluginMeasurements. Used internally.
    """
    def __init__(self, timestamp=None, measurements=None):
        self.timestamp = timestamp
        self.measurements = measurements

    @property
    def timestamp(self):
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        self._timestamp = None
        if timestamp:
            self._timestamp = int(timestamp)

    @property
    def measurements(self):
        return self._measurements

    @measurements.setter
    def measurements(self, measurements):
        self._measurements = []
        if measurements:
            for m in measurements:
                if not isinstance(m, BaseMetric):
                    raise TypeError("Each measurement should be an instance of BaseMetric, got %s instead" % type(m))
            self._measurements = measurements

    @property
    def is_empty(self):
        return len(self._measurements) == 0

    @property
    def length(self):
        return len(self._measurements)
