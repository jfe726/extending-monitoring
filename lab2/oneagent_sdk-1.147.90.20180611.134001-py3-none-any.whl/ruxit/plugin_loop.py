import json
import sys
import logging
import logging.handlers
import time
import pprint
import itertools
import ruxit.plugin_state_machine
import ruxit.config_utils
import ruxit.plugin_status_reporter
import ruxit.mem_tracking
import ruxit.utils.fault_handling
import ruxit.utils.perf_utils
import ruxit.utils.murmur
import traceback
from .utils.execute_every_minute import ExecuteEveryMinute
from .package_utils import plugin_updater as plugin_update_mod
logger = logging.getLogger(__name__)


def _do_nothing(self, *args, **kwargs):
    pass


class PluginTask:
    def __init__(self, engine, follow_up=None, timestamp=None):
        self.engine = engine
        self.follow_up = follow_up
        self.created_timestamp = timestamp
        if timestamp is None:
            self.created_timestamp = time.monotonic()
        if follow_up is None:
            self.follow_up = _do_nothing

    def __repr__(self):
        return "PluginTask(engine=%s,follow_up=%s,created_timestamp=%s" % (
            self.engine,
            self.follow_up,
            self.created_timestamp
        )


class PluginLoop:
    def __init__(self,
                 concurrent_mod,
                 stop_strategy,
                 report_results_strategy,
                 get_metadata_strategy,
                 platform_api):

        self.pending_disabled = []
        self.concurrent_mod = concurrent_mod
        self.executor = self.concurrent_mod.ThreadPoolExecutor(max_workers=4)

        self.step_timeout = 2
        self.shutdown_timeout = 8

        self.plugin_engines = []
        self.incompatible_plugins = []
        self.pending_execution = []
        self.submitted_tasks = {}

        self.latest_plugin_infos = []

        self.report_results_strategy = report_results_strategy
        self.get_metadata_strategy = get_metadata_strategy
        self.stop_strategy = stop_strategy
        self.platform_api = platform_api

        self.status_every_minute = ExecuteEveryMinute()
        self.plugin_reporter = ruxit.plugin_status_reporter.PluginStatusReporter(self.platform_api.external_api)

        self.mem_driver = ruxit.mem_tracking.TracemallocDriver(external_api=self.platform_api.external_api)

        log_path = self.platform_api.external_api.get_log_path()
        ruxit.utils.murmur.Murmur().initialize(self.platform_api.external_api)
        self.fault_handler_trap = ruxit.utils.fault_handling.FaultHandlerTrap(fault_info_dir=log_path)
        self.hung_plugin_reporter = ruxit.utils.fault_handling.HungPluginsReporter(fault_info_dir=log_path)
        self.plop_driver = ruxit.utils.perf_utils.PlopDriver(external_api=self.platform_api.external_api)

    def main(self):
        self._update_logging_configuration()
        self._update_plugin_metadata()
        process_mem = self._create_processmem()
        support_alert_creator = self.platform_api.get_support_alert_creator()

        while self.should_run():
            time_start = time.monotonic()

            if not self.platform_api.external_api.should_pause():
                next(support_alert_creator)
                process_mem()
                self.one_plugin_loop_step()
            self.plop_driver.step()

            if hasattr(sys, 'gettotalrefcount'):
                logger.debug("totalrefcount: %s", sys.gettotalrefcount())

            work_time = time.monotonic() - time_start
            time_left = self.step_timeout - work_time
            if time_left > 0:
                logger.debug("nothing to do, sleeping for %s", time_left)
                time.sleep(time_left)

            self.status_every_minute.do(
                logger.info,
                "Plugin loop status: time_taken: %s, engines_info: %s, ",
                work_time,
                pprint.pformat(["%s, executions:%s " % (pe, pe.get_execution_count()) for pe in self.plugin_engines]),
            )

        self.shutdown()

    def _create_processmem(self):
        mem_driver_interval = self.platform_api.external_api.get_int_debug_flag(
            "debugPluginAgentTracemallocIntervalNative",
            180
        )
        process_mem = ruxit.mem_tracking.run_on_interval_decorator(
            lambda: self.mem_driver.process_memory_usage(),
            mem_driver_interval
        )
        return process_mem

    def one_plugin_loop_step(self):
        self._update_logging_configuration()
        if self.platform_api.data_update():
            self.trigger_plugins_life(self.latest_plugin_infos)
        self.trigger_state_machines()

        done_futures, not_done_futures = self.concurrent_mod.wait(self.submitted_tasks.keys(), timeout=self.step_timeout)
        for done_future in done_futures:
            plugin_task = self.submitted_tasks[done_future]
            plugin_engine = plugin_task.engine
            plugin_engine.execution_timeout = False
            del self.submitted_tasks[done_future]
            try:
                # in order to catch exceptions originating from plugins
                done_future.result()
                plugin_task.follow_up(plugin_engine)
            except Exception as ex:
                plugin_engine.get_logger().info("plugin %s threw exception %s", plugin_engine, ex)

            if plugin_engine not in self.pending_disabled:
                self.pending_execution.append(plugin_engine)
            else:
                self.pending_disabled.remove(plugin_engine)

        self.hung_plugin_reporter.report_hung_tasks(self.submitted_tasks)

        self.gather_stats()

        self.report_plugins_status()

        return done_futures, not_done_futures

    def _report_plugin_results(self, plugin_engine):
        result = plugin_engine.flush_results()
        if result is None:
            plugin_engine.get_logger().warn("No results available from plugin_engine %s" % plugin_engine)
            return
        if plugin_engine.get_logger().isEnabledFor(logging.DEBUG):
            plugin_engine.get_logger().debug("Plugin finished engine=%s, result=%s", plugin_engine, pprint.pformat(result))

        self.report_results_strategy(
            result.measurements,
            result.properties,
            result.events
        )

        self.platform_api.additional_report_step(plugin_engine)

    def _update_plugin_metadata(self):
        updated_metadata = self.get_metadata_strategy()
        if self.platform_api.external_api.resolve_conflicts_flag():
            logger.info('Installing plugins with conflict resolution')
            plugin_updater = plugin_update_mod.PluginUpdater(
                sys.path,
                updated_metadata
            )
            plugin_entries = plugin_updater.install_plugins()
            self.incompatible_plugins = plugin_updater.incompatible_plugins
            logger.info('========= INCOMPATIBLE PLUGINS =========')
            logger.info(pprint.pformat(self.incompatible_plugins))
            logger.info('='*40)
            logger.info('*'*40)
            logger.info(plugin_entries)
            logger.info('*'*40)
            self.latest_plugin_infos = plugin_entries
            sys.path.extend([entry.directory for entry in plugin_entries])
            logger.info("sys.path after installing plugins: %r", sys.path)
        else:
            logger.info("Installing plugins using old mechanism (no conflict resolution)")
            self.latest_plugin_infos = [
                plugin_update_mod.PluginInfo(json_data=json.loads(mt[1]), directory=mt[0]) for mt in updated_metadata
            ]
            for directory_metadata in updated_metadata:
                if directory_metadata[0] not in sys.path:
                    sys.path.append(directory_metadata[0])
                    logger.info('appending %s to sys.path', directory_metadata[0])
        if logger.isEnabledFor(logging.DEBUG):
                    logger.debug("Latest plugin metadata: %s", pprint.pformat(self.latest_plugin_infos))

    def trigger_plugins_life(self, plugin_metadata):
        to_activate, to_deactivate = self.platform_api.select_plugins(self.plugin_engines, plugin_metadata)
        plugins_changed = False
        for engine_activation_context, plugin_info in to_activate:
            try:
                plugins_changed = True

                engine = self.platform_api.create_engine(plugin_info, engine_activation_context)
                engine.get_logger().info(
                    "Activating plugin engine: %s \ninfo: %s \nactivation_context: %s",
                    engine,
                    plugin_info, engine_activation_context
                )
                if engine.get_logger().isEnabledFor(logging.DEBUG):
                    engine.get_logger().debug("Activated engine full metadata: %s", pprint.pformat(plugin_info.json_data))
                self.pending_execution.append(engine)
                self.plugin_engines.append(engine)
            except:
                logger.exception ("Unable to create plugin %s because of %s",
                                  'plugin_info.json_data.metadata["source"]["className"]',
                                  sys.exc_info())

        for inactive_engine in to_deactivate:
            plugins_changed = True
            inactive_engine.get_logger().info(
                    "Removing plugin engine: %s, activation_context: %s",
                    inactive_engine,
                    inactive_engine.activation_context
            )
            self.plugin_engines.remove(inactive_engine)
            self.plugin_reporter.remove_engine(inactive_engine)
            if inactive_engine in self.pending_execution:
                self.pending_execution.remove(inactive_engine)
            else:
                self.pending_disabled.append(inactive_engine)

        if plugins_changed:
            logger.info("active plugins changed")

    def trigger_state_machines(self):
        new_pending_execution = []
        for plugin_engine in self.pending_execution:
            future = None
            follow_up = None

            new_config, fast_check_id, _ = self.platform_api.get_plugin_config(plugin_engine, self.latest_plugin_infos)
            
            if fast_check_id:
                plugin_engine.request_fast_check(fast_check_id)
            plugin_uninitialized = not plugin_engine.is_initialized()
            if plugin_engine.ready_for_set_config(new_config, fast_check_id):
                future = self.executor.submit(
                    plugin_engine.event_set_configuration,
                    new_config
                )
                follow_up = self._report_plugin_results
            elif new_config is None and not plugin_uninitialized:
                future = self.executor.submit(plugin_engine.event_disable)
            elif plugin_engine.ready_for_measure():
                future = self.executor.submit(plugin_engine.event_gather_measurements)
                follow_up = self._report_plugin_results

            if future is not None:
                self.submitted_tasks[future] = PluginTask(plugin_engine, follow_up=follow_up)
            else:
                new_pending_execution.append(plugin_engine)

        self.pending_execution = new_pending_execution

    def shutdown(self):
        logger.info("Shutting down plugin loop")
        not_cancelled = []
        cancelled = []

        # cancel plugins that can be cancelled
        for future in self.submitted_tasks:
            cancel_result = future.cancel()
            if not cancel_result:
                not_cancelled.append(future)
            else:
                cancelled.append(future)
        # wait for all executing plugins
        done, not_done = self.concurrent_mod.wait(not_cancelled, timeout=self.shutdown_timeout)

        # schedule closing of all plugins
        shutdown_tasks = []
        for future in itertools.chain(cancelled, done):
            plugin_engine = self.submitted_tasks[future].engine
            future = self.executor.submit(plugin_engine.shutdown)
            shutdown_tasks.append(future)
        # wait for them to shut down
        shut_down, not_shut_down = self.concurrent_mod.wait(shutdown_tasks, timeout=self.shutdown_timeout)

        self.executor.shutdown(wait=False)
        logger.info("Plugin loop shutdown finished")

    def gather_stats(self):
        for engine in self.plugin_engines:
            if engine.get_logger().isEnabledFor(logging.DEBUG):
                engine.get_logger().debug('Plugin Stats for engine %s: \n%s', engine, pprint.pformat(engine.get_stats()))

    def should_run(self):
        return next(self.stop_strategy) and self.platform_api.external_api.plugins_enabled()

    def report_plugins_status(self):
        self.plugin_reporter.report_status(reversed(self.plugin_engines), self.incompatible_plugins)

    def _update_logging_configuration(self):
        # we're setting this on root logger, so all other loggers are affected
        if self. platform_api.external_api.is_debug_logging_enabled() is True:
            logging.getLogger().setLevel(logging.DEBUG)
        else:
            logging.getLogger().setLevel(logging.INFO)

def dump_stack():
    code = []
    for threadId, stack in sys._current_frames().items():
        code.append("\n# Thread: %d" % (threadId))
        for filename, lineno, name, line in traceback.extract_stack(stack):
            code.append('File: "%s", line %d, in %s' % (filename, lineno, name))
            if line:
                code.append("  %s" % (line.strip()))
    logger.info("\n".join(code))
    return code


def main(stop_strategy, report_results_strategy, get_metadata_strategy, platform_api):
    import concurrent.futures
    import atexit
    atexit.unregister(concurrent.futures.thread._python_exit)
    loop = PluginLoop(
        stop_strategy=stop_strategy,
        concurrent_mod=concurrent.futures,
        report_results_strategy=report_results_strategy,
        get_metadata_strategy=get_metadata_strategy,
        platform_api=platform_api)
    loop.main()
