import collections
import logging
import copy
PluginConfigInfo = collections.namedtuple("PluginConfigInfo", ["name", "properties", "fast_id", "enabled"])


def create_config(plugin_info, received_configs, logger = logging.getLogger(__name__)):
    # we always expect metadata for the plugin to be present
    plugin_name = plugin_info.reported_name
    meta = plugin_info.json_data
    meta_properties = meta.get('properties', [])
    config = {}
    missing_properties = set()
    for property in meta_properties:
        if 'defaultValue' in property:
            config[property['key']] = property['defaultValue']
        else:
            missing_properties.add(property['key'])

    received_config = received_configs.get(plugin_name, None)
    fast_id = ()
    # we cannot know if plugin is enabled or disabled until we receive at least one configuration response
    # therefore even if plugin does not require configuration, we must wait until we receive config
    enabled = plugin_info.is_in_development
    if received_config:
        for property_name, property_value in received_config.properties.items():
            if property_value is not None:
                config[property_name] = property_value
                missing_properties.discard(property_name)
        if not plugin_info.is_in_development:
            enabled = received_config.enabled
        fast_id = received_config.fast_id
        if not enabled:
            logger.debug("Received disabled config for plugin %s", plugin_info)
    if logger.isEnabledFor(logging.DEBUG) and len(missing_properties) > 0:
        logger.debug("Incomplete config for plugin: %s, missing_properties: %s", plugin_info, missing_properties)
    return config, enabled and len(missing_properties) == 0, fast_id


def remove_sensitive_config_data(one_meta, one_config):
    meta_properties = one_meta.get('properties', [])
    meta_prop_by_key = {}
    for meta_property in meta_properties:
        meta_prop_by_key[meta_property["key"]] = meta_property

    sensitive_data_masked = copy.deepcopy(one_config)

    for config_key, config_value in sensitive_data_masked.items():
        meta_prop = meta_prop_by_key.get(config_key, {"type": "String"})
        if meta_prop["type"] == 'Password':
            sensitive_data_masked[config_key] = "########"
        else:
            # OpenStack-specific fix for APM-117681
            if config_key == 'OpenStackCredentials':
                for conf in config_value:
                    if conf['password']:
                        conf['password'] = "########"

    return sensitive_data_masked

