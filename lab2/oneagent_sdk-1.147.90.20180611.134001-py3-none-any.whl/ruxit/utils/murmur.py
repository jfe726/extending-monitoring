import typing


class Murmur:
    __instance = None

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = object.__new__(cls)
            cls.__instance._initialized = False
        return cls.__instance

    @staticmethod
    def initialize(external_api):
        Murmur()._init(external_api)

    def _init(self, external_api):
        if self._initialized:
            return
        self.__murmur2 = external_api.murmur_hash_2_64
        self._initialized = True

    def murmur2(self, data: str) -> str:
        return self.__murmur2(data)
