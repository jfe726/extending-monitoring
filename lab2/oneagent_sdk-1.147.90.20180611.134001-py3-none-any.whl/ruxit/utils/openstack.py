from ruxit.utils.firewall import InternalAPI
import typing
import json
import requests
import logging
import datetime
import threading
from ruxit.api.exceptions import ConfigException, AuthException
from ruxit.utils.murmur import Murmur


def __calculate_id(instance_id: str) -> int:
    return Murmur().murmur2(instance_id)

@InternalAPI
def get_vm_id(instance_id: str) -> int: 
    return __calculate_id(instance_id)

@InternalAPI
def get_project_id(instance_id: str) -> int:
    return __calculate_id(instance_id)

class GetToken:
    __logger = logging.getLogger()
    __lock = threading.Lock()

    __expires = 0
    __config = None
    __token = ""

    def __new__(cls, config: dict=None):
        if config != None:
            if cls.__config != config:
                cls.__expires = 0
            cls.__config = config
        return cls

    @classmethod
    @InternalAPI
    def get_token(cls, fresh_token: bool=False) -> str:
        cls.__lock.acquire(10)

        if (datetime.datetime.now().timestamp() > cls.__expires) or fresh_token:
            try:
                CredentialsChecker(cls.__config, cls.__logger)

                cls.__logger.debug("url: %s" % (CredentialsChecker.url))
                cls.__logger.debug("json: %s" % (CredentialsChecker.json))

                response = requests.post(
                    CredentialsChecker.url, headers=Headers.json(),
                    json=CredentialsChecker.json, timeout=50.0, verify=False)
                cls.__logger.debug("response: %s" % (response))

                if response.status_code >= 500:
                    raise requests.HTTPError()
                if response.status_code >= 400:
                    raise AuthException("Keystone authentication failed")

                if CredentialsChecker.api_ver == '3':
                    if 'X-Subject-Token' not in response.headers:
                        raise AuthException("X-Subject-Token not found in response header")
                    cls.__expires = datetime.datetime.strptime(response.json()['token']['expires_at'], \
                        '%Y-%m-%dT%H:%M:%S.%fZ').timestamp() if 'expires_at' in response.json()['token'] else 0
                    cls.__token = response.headers['x-subject-token']

                elif CredentialsChecker.api_ver == '2':
                    cls.__expires = datetime.datetime.strptime(response.json()['access']['token']['expires'], \
                        '%Y-%m-%dT%H:%M:%SZ').timestamp() if 'expires' in response.json()['access']['token'] else 0
                    cls.__token = response.json()['access']['token']['id']

                else :
                    raise ConfigException("Unsupported API version %s" % CredentialsChecker.api_ver)

                cls.__logger.debug("auth token json %s" % (response.json()))
                cls.__logger.debug("auth token %s" % (cls.__token))

            except Exception as ex:
                cls.__lock.release()
                raise ex

        cls.__lock.release()
        return cls.__token

class Headers:
    @staticmethod
    def json():
        return {"Content-type": "application/json"}

class UrlConstructor:

    def __init__(self, cred, logger):
        self._url_to_check = UrlConstructor._prepareUrl(cred['keystoneBinding'])
        self._domain = cred['domain']
        self._logger = logger
        self._api_ver = ''
        self._url = ''

    @staticmethod
    def _prepareUrl(url):
        return "https://" + url if not url.startswith("http") else url

    @staticmethod
    def getFirstDigit(s):
        for i in s:
            if i.isdigit():
                return i
        return '0'

    @staticmethod
    def checkIfHttps(url, logger):
        try :
            r = requests.get(url, timeout=50.0, verify=False)
            return url
        except Exception as ex :
            logger.info("Error reaching location %s: %s. Trying without https..." % (url, str(ex)))

        if not url.startswith("https") :
            logger.info("Cannot convert url: %s from https to http. Raising requests.HTTPError..." % (url))
            raise requests.HTTPError()

        url = url.replace("https", "http")
        try :
            r = requests.get(url, timeout=50.0, verify=False)
        except Exception as ex:
            logger.info("Error reaching location %s: %s. Rising requests.HTTPError..." % (url, str(ex)))
            raise requests.HTTPError() from ex

        return url

    @staticmethod
    def _queryVersions(url, logger):
        response = requests.get(url, headers=Headers.json(), timeout=50.0, verify=False)
        logger.debug("query version response: %s" % (response))
        if response.status_code >= 400:
            raise requests.HTTPError()

        versions_json = response.json()
        logger.debug("supported versions json %s" % (versions_json))
        return versions_json

    def get(self):
        self._url_to_check = UrlConstructor.checkIfHttps(self._url_to_check, self._logger)
        versions_json = UrlConstructor._queryVersions(self._url_to_check, self._logger)

        api_link = ''
        for ver in versions_json['versions']['values']:
            link = next((x for x in ver['links'] if x['rel'] == 'self'), None)
            if link is None:
                continue
            if self._domain == '' and UrlConstructor.getFirstDigit(ver['id']) != '2' :
                continue
            self._api_ver = UrlConstructor.getFirstDigit(ver['id'])
            api_link = link['href']
            break
        if not api_link:
            raise ConfigException('No supported version reported')

        # link returned in versions can be absolute and relative
        url = api_link if api_link.startswith('http') else (self._url_to_check + api_link)
        # different APIs have different auth url
        if self._api_ver == '2':
            self._url = url + "tokens"
        elif self._api_ver == '3':
            self._url = url + "auth/tokens"
        else :
            raise ConfigException("Unsupported API version %s" % self._api_ver)

        return self._url

    def api_ver(self):
        self.get()
        return self._api_ver

class CredentialsChecker:

    class Credentials:
        pass

    url = ''
    json = ''
    api_ver = ''

    def __init__(self, config, logger):
        self._config = config
        self._logger = logger
        
        self._discover_credentials()

    def _get_credentials(self, credentials_json):
        for cred in credentials_json:
            urlConstructor = UrlConstructor(cred, self._logger)
            credentials = CredentialsChecker.Credentials()
            credentials.url = urlConstructor.get()
            credentials.api_ver = urlConstructor.api_ver()
            credentials.user = cred["user"]
            credentials.password = cred["password"]
            credentials.tenant = cred["project"]
            credentials.domain = cred["domain"] or 'default'
            local_json = self._get_json(credentials)

            response = requests.post(credentials.url, headers=Headers.json(), 
                json=local_json, timeout=50.0, verify=False)

            if response.status_code >= 500:
                raise requests.HTTPError()
            if response.status_code >= 400:
                self._logger.debug("request failed for: url=%s json=%s" % (credentials.url, local_json))
                self._logger.debug("response: %s" % (response))
                self._logger.debug("status: %s for request: %s, trying next credentials" % 
                    (response.status_code, local_json))
                continue

            if credentials.api_ver == '3':
                resp_headers = response.headers
                if 'X-Subject-Token' not in resp_headers:
                    self._logger.debug(
                        "X-Subject-Token not found in response header for request: %s, \
                        trying next credentials" % (local_json))
                    continue

            return credentials

        raise AuthException("Keystone authentication failed")

    def _discover_credentials(self):
        if CredentialsChecker.url and CredentialsChecker.json:
            return

        credentials = self._get_credentials(self._config['OpenStackCredentials'])
        CredentialsChecker.url = credentials.url
        CredentialsChecker.api_ver = credentials.api_ver
        CredentialsChecker.json = self._get_json(credentials)

    def _get_json(self, credentials):
        api_version = credentials.api_ver
        user = credentials.user
        password = credentials.password
        tenant = credentials.tenant
        domain = credentials.domain

        if '2' == api_version:
            return {
                'auth': {
                    'tenantName': tenant,
                    'passwordCredentials': {
                        'username': user,
                        'password': password
                    }
                }
            }
        elif '3' == api_version:
            return {
                'auth': {
                    'identity': {
                        'methods': ['password'],
                        'password': {
                            'user': {
                                'name': user,
                                'domain': {'name': domain},
                                'password': password
                            }
                        }
                    }
                }
            }
        else:
            raise ConfigException(
                "Unsupported API version %s" % api_version)