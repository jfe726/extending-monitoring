import logging
import sys
import argparse
import os
import json
import requests
import urllib.parse
import re

from ruxit.tools import osagent_default_dirs, rpa_default_dirs, build_plugin
from ruxit.tools.default_dir_provider import DefaultDirProvider

logging.basicConfig(stream=sys.stderr, format="%(message)s", level=logging.INFO)
logger = logging.getLogger(__package__)
requests_log = logging.getLogger("requests")


def _get_dir_provider(remote):
    dir_provider = DefaultDirProvider(remote)
    return dir_provider


def main():
    parsed_args = None
    try:
        parsed_args = parse_args(sys.argv[1:])
        if parsed_args.verbose:
            logger.setLevel(logging.DEBUG)
            requests_log.setLevel(logging.DEBUG)
        main_body(parsed_args.plugin_zip, parsed_args.server, parsed_args.token, parsed_args.token_file,
                  parsed_args.no_cert_ver)
    except Exception as ex:
        logger.error("Error occured: %s", ex)
        if parsed_args and parsed_args.verbose:
            logger.exception("Error details:")
        if str(ex).find("CERTIFICATE_VERIFY_FAILED") != -1:
            logger.info("You can try to execute script with --no_cert_ver, to disable ssl certificate verification")
        sys.exit(1)


def is_remote(plugin_name):
    # Zip name is generated from plugin name so it should have "remote" entry in zip-name
    words = plugin_name.split(".")
    return words[1] == "remote"


def main_body(plugin_zip, server, token, token_file, no_cert_ver):
    logger.debug('plugin upload script starts')
    zip_file = _get_zip_filename(plugin_zip)
    server_names = get_server_names(is_remote(zip_file), server)
    token = get_token(is_remote(zip_file), token, token_file)

    if zip_file is not None and server_names and token is not None:
        headers = {'Authorization': 'Api-Token ' + token}
        verify_cert = False if no_cert_ver else True
        for server_url in server_names:
            logger.info('Attempting to send plugin to server %s', server_url)
            files = {'file': open(zip_file, 'rb')}
            server_address = _create_full_api_url(server_url, server is not None, is_remote(zip_file))
            try:
                response = requests.post(server_address, headers=headers, files=files, verify=verify_cert)
            except:
                logger.info('Unable to establish connection with server %s', server_address)
                continue
            if response.status_code != 200:
                logger.info('server %s returned status code: %d %s', server_address, response.status_code,
                            response.text)
                if response.status_code == 400:
                    logger.info(
                        "Please execute oneagent_build_plugin before uploading plugin to validate if plugin.json is ok")
                    return False
                continue
            else:
                logger.info('plugin has been uploaded successfully')
                logger.debug('server %s returned status code: %d %s', server_address, response.status_code,
                             response.text)
                return True
        return False
    logger.info('Error: one of the following is missing: plugin zip file | server address | token')


def _read_plugin_name_from_json(plugin_json_path):
    logger.debug("Checking plugin metadata: %s", plugin_json_path)
    try:
        with open(plugin_json_path, 'r') as fp:
            json_data = json.load(fp)
            return json_data["name"]
    except Exception as ex:
        logger.exception("Error %s when parsing plugin.json file: %s", ex, plugin_json_path)
    return None


def _get_zip_filename(plugin_zip):
    if plugin_zip is None:
        plugin_name = _read_plugin_name_from_json(os.path.join(os.getcwd(), "plugin.json"))
        plugin_dev_dir = _get_dir_provider(is_remote(plugin_name)).get_default_target_root()
        if plugin_name is not None and plugin_name != "":
            plugin_zip = os.path.join(plugin_dev_dir, plugin_name + ".zip")
    else:
        if not re.compile(build_plugin.CUSTOM_PLUGIN_NAME).match(plugin_zip.split(os.path.sep)[-1]):
            raise Exception("Plugin zip name should match: %s" % build_plugin.CUSTOM_PLUGIN_NAME)
    logger.debug('plugin zip filename: %s', plugin_zip)
    return plugin_zip


def get_server_names(remote, server):
    if server is None:
        base_path = _get_dir_provider(remote).get_default_config_persistence_dir() if not remote else _get_dir_provider(remote).get_default_conf_dir()
        config_file_path = os.path.join(base_path, 'plugin_sdk.conf') if not remote else os.path.join(base_path,
                                                                                                         'ruxitagent.conf')
        try:
            with open(config_file_path) as f:
                content = f.readlines()
        except Exception as ex:
            logger.exception("Error %s when parsing file: %s", ex, config_file_path)
            return []
        for line in content:
            line = line.strip()
            if not remote and line.startswith('pluginUploadUrls '):
                urls = line.split('pluginUploadUrls ')[1]
                return [url for url in urls.split(';') if url]
            if remote and line.startswith('Server'):
                url = line.split('Server ')[1]
                return [url.rsplit('/', 1)[0]]  # Remove 'communication' endpoint int url
        logger.info('Error when parsing %s file: file does not contain server address', config_file_path)
        return []
    logger.debug('server address: %s', server)
    return [server]


def _create_full_api_url(server_url, server_provided, remote):
    if not server_provided:
        if not server_url.endswith('/'):
            server_url += '/'
        return server_url
    else:
        server_parts = urllib.parse.urlparse(server_url)
        server_url = server_parts.geturl() if not server_parts.path.startswith('/api/') else server_parts.scheme + "://" + server_parts.netloc
        remote_part = 'remote' if remote else ''
        new_path = '{0}/api/v1/{1}plugins'.format(server_url, remote_part)
        return new_path


def get_token(remote, token, token_file):
    if token is not None:
        return token
    if token_file is None:
        token_file = os.environ.get('ONEAGENT_PLUGIN_UPLOAD_TOKEN')
    if token_file is None:
        token_file = os.path.join(_get_dir_provider(remote).get_default_conf_dir(), 'plugin_upload.token')
    if not os.path.isfile(token_file):
        logger.info('could not find token file - launch "oneagent_upload_plugin --help" to get more information')
        return None
    logger.debug("reading token from file %s", token_file)
    with open(token_file) as f:
        token = f.read()
        token = token.strip()
        logger.debug("token found in file: %s", token)
        return token


def parse_args(cmd_args):
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', "--plugin_zip",
                        help="plugin zip path (default location of oneagent_build_plugin is taken by default)")
    parser.add_argument("-v", "--verbose", help="increase verbosity", action="store_true")
    parser.add_argument("--no_cert_ver", help="turn off ssl certificate verification", action="store_true")
    parser.add_argument(
        "-s",
        "--server",
        help="server address (taken from oneagent configuration file by default)"
    )
    parser.add_argument(
        "-t",
        "--token",
        help="set the authentication token (token file is used if token is not set)"
    )
    parser.add_argument(
        "-T",
        "--token_file",
        help="set the authentication token file (by default env variable ONEAGENT_PLUGIN_UPLOAD_TOKEN, or plugin_upload.token from configuration directory if env variable is not specified)"
    )
    return parser.parse_args(cmd_args)


if __name__ == '__main__':
    main()
