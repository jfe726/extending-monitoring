import logging

# this import is conditional only because code coverage tests would fail otherwise
try:
    import remote_embedded_api
except ImportError:
    pass


class RemoteLogHandler(logging.Handler):
    _level_mapping = {
        logging.NOTSET: 8,
        logging.DEBUG: 7,
        logging.INFO: 4,
        logging.WARNING: 5,
        logging.ERROR: 6,
        logging.FATAL: 6,
    }

    def __init__(self):
        super().__init__()

    def emit(self, record):
        msg = self.format(record).encode('ascii', errors='replace')
        remote_embedded_api.api_object.log(self._level_mapping[record.levelno], msg)
