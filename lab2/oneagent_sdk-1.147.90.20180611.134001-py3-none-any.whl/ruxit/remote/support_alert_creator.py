from collections import deque, namedtuple
from typing import Callable, List


class EventWindow(object):

    def __init__(self, event_window_size: int, metric: str, threshold_callback: Callable):
        self.window = deque(maxlen=event_window_size)
        self.metric = metric
        self.threshold_callback = threshold_callback
        self.last_value = None

    def trigger(self, event) -> int:
        self.last_value = getattr(event, self.metric)
        self.window.append(self.last_value)
        threshold = self.threshold_callback()
        return sum(i > threshold for i in self.window)

    def get_last_value(self) -> int:
        return self.last_value


class EventWindowsObserver(object):
    OBSERVED_EVENT = namedtuple("ObservedEvent", ["alert_callback", "event_window"])

    def __init__(self, event_callback: Callable, event_window_size: int, event_window_occurrence_threshold: int):
        self.event_callback = event_callback
        self.event_window_size = event_window_size
        self.event_window_occurrence_threshold = event_window_occurrence_threshold
        self.observed_events = []

    def observe(self, alert_callback: Callable, metric: str,  threshold_callback: Callable) -> None:
        self.observed_events.append(
            EventWindowsObserver.OBSERVED_EVENT(
                alert_callback=alert_callback,
                event_window=EventWindow(self.event_window_size, metric, threshold_callback)
            )
        )

    def __iter__(self):
        return self

    def __next__(self) -> None:
        event = self.event_callback()
        for observed_event in self.observed_events:
            if observed_event.event_window.trigger(event) >= self.event_window_occurrence_threshold:
                observed_event.alert_callback(str(observed_event.event_window.get_last_value()))


class SupportAlertCreator(object):
    DEFAULT_CPU_LIMIT = 5
    DEFAULT_MEMORY_LIMIT = 200000000
    OBSERVED_EVENT = namedtuple("ObservedEvent", ["threshold_callback", "metric", "alert_callback"])

    def __init__(self, event_callback: Callable, observed_events: List[OBSERVED_EVENT]):
        self.event_windows_observer = EventWindowsObserver(event_callback=event_callback,
                                                           event_window_size=5,
                                                           event_window_occurrence_threshold=3)
        for observed_event in observed_events:
            self.event_windows_observer.observe(
                alert_callback=observed_event.alert_callback,
                metric=observed_event.metric,
                threshold_callback=observed_event.threshold_callback
            )

    def __iter__(self):
        return self

    def __next__(self) -> None:
        next(self.event_windows_observer)
