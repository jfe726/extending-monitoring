"""
TopologyBuilder module provides an API for the plugins to send the information about the topology.
"""
from typing import NamedTuple, Set, List
import hashlib
import logging
from ruxit.api.results_builder import ResultsBuilder
from ruxit.api.data import PluginMeasurement, PluginMeasurementStatCounter, PluginProperty, MEAttribute, \
    PluginStateMetric, StatCounterDataPoint
from abc import abstractproperty
from typing import Dict

from ruxit.api.selectors import ExplicitSelector, EntityType
from ruxit.api.events import Event, EventType, EventMetadata, EventMetadataKey

logger = logging.getLogger(__name__)

def hash_id(*args):
    """
    Creates a new numeric entity id from all passed arguments.

    Args:
        *args: The parameters to be hashed together.
    """
    h = hashlib.md5()

    h.update((2).to_bytes(8, byteorder="little"))

    # combine everything passed to the function
    for item in args:
        if isinstance(item, int):
            item = item.to_bytes(8, byteorder="little")
        elif isinstance(item, str):
            item = str.encode(item)

        try:
            h.update(item)
        except:
            logger.warn("Error when hashing %s for entity ID calculation" % item)
            raise

    # convert the hex string to an int
    return int(h.hexdigest()[:16], 16)

# some type aliases for common stuff
EntityId = int
Endpoint = NamedTuple("Endpoint", [("ip", str), ("port", int), ("domain_names", List[str])])


class MetricSink:
    def __init__(self, results_builder: ResultsBuilder):
        self._results_builder = results_builder

    @abstractproperty
    def selector(self):
        return

    def absolute(self, key: str, value: float, dimensions: Dict[str, str]=None):
        self._results_builder.add_absolute_result(PluginMeasurement(key=key, value=value, dimensions=dimensions,
                                                                    entity_selector=self.selector))

    def relative(self, key: str, value: float, dimensions: Dict[str, str]=None):
        self._results_builder.add_relative_result(PluginMeasurement(key=key, value=value, dimensions=dimensions,
                                                                    entity_selector=self.selector))

    def per_second(self, key: str, value: float, dimensions: Dict[str, str]=None):
        self._results_builder.add_per_second_result(PluginMeasurement(key=key, value=value, dimensions=dimensions,
                                                                      entity_selector=self.selector))

    def stat_counter(self, key: str, value: StatCounterDataPoint, dimensions: Dict[str, str]=None):
        self._results_builder.add_absolute_stat_counter_result(PluginMeasurementStatCounter(key=key, value=value, dimensions=dimensions,
                                                                      entity_selector=self.selector))

    def report_property(self, key: str, value: str):
        """
               Reports a property.

               Args:
                   key: Property key as string.
                   value: Property value as string.
               """
        self._results_builder.add_property(
            PluginProperty(entity_selector=self.selector, me_attribute=MEAttribute.CUSTOM_DEVICE_METADATA,
                           key=key,
                           value=value))

class Element(MetricSink):
    """
    Class used to store element data reported from the plugin.
    """
    def __init__(self, name: str, entity_id: EntityId, technology: str, results_builder: ResultsBuilder) -> None:
        super().__init__(results_builder)
        self._name = name
        self._id = entity_id
        self._endpoints = []
        self._technology = technology
        self._results_builder = results_builder

    @property
    def name(self):
        return self._name

    @property
    def id(self):
        return self._id

    @property
    def selector(self):
        return ExplicitSelector(self._id, EntityType.CUSTOM_DEVICE)

    @property
    def technology(self):
        return self._technology

    @property
    def endpoints(self):
        return self._endpoints

    def add_endpoint(self, ip: str, port: int, **kwargs) -> None:
        dns_names = kwargs.get('dnsNames', None)
        self.endpoints.append((ip, int(port), dns_names))


    def report_performance_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {}):
        """
        Reports a performance event.

        Optional args:
            description: Event description as string.
            title: Event title as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_performance_event(description=description, title=title, properties=properties, entity_selector=self.selector)

    def report_error_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {}):
        """
        Reports an error event.

        Optional args:
            description: Event description as string.
            title: Event title as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_error_event(description=description, title=title, properties=properties, entity_selector=self.selector)

    def report_availability_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {}):
        """
        Reports an availability event.

        Optional args:
            description: Event description as string.
            title: Event title as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_availability_event(description=description, title=title,
                                              properties=properties, entity_selector=self.selector)

    def report_resource_contention_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {}):
        """
        Reports a resource contention event.

        Optional args:
            description: Event description as string.
            title: Event title as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_resource_contention_event(description=description, title=title,
                                              properties=properties, entity_selector=self.selector)

    def report_custom_info_event(self, description: str = None, title: str = None, properties: Dict[str, str] = {}):
        """
        Reports a custom info event.

        Optional args:
            description: Event description as string.
            title: Event title as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_custom_info_event(description=description, title=title,
                                              properties=properties, entity_selector=self.selector)

    def report_custom_deployment_event(self,
                                       source: str = None,
                                       project: str = None,
                                       version: str = None,
                                       ci_link: str = None,
                                       remediation_action_link: str = None,
                                       deployment_name: str = None,
                                       properties: Dict[str, str] = {}):
        """
        Reports a custom deployment event.

        Optional args:
            source: Event source as string.
            project: Event project as string.
            version: Event version as string.
            ci_link: Event link as string
            remediation_action_link: Event remediation action link as string.
            deployment_name: Event deployment name as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_custom_deployment_event(source=source,
                                                             project=project,
                                                             version=version,
                                                             ci_link=ci_link,
                                                             remediation_action_link=remediation_action_link,
                                                             deployment_name=deployment_name,
                                                             properties=properties,
                                                             entity_selector=self.selector
                                                             )


    def report_custom_annotation_event(self,
                                       description: str = None,
                                       annotation_type: str = None,
                                       source: str = None,
                                       properties: Dict[str, str] = {}):
        """
        Reports a custom annotation event.

        Optional args:
            description: Event description as string.
            annotation_type: Event annotation_type as string.
            source: Event source as string.
            properties: Event properties as dictionary of 2 strings.
        """
        self._results_builder.report_custom_annotation_event(description=description,
                                                             annotation_type=annotation_type,
                                                             source=source,
                                                             properties=properties,
                                                             entity_selector=self.selector
                                                             )

    def state_metric(self, key: str, value: str, dimensions: Dict[str, str]=None):
        """
                Reports a state metric.

                Args:
                    key: mandatory state metric name as string.
                    value: mandatory state metric value as string.
                    dimensions: optional metric dimensions as dictionary of 2 strings.
                """
        self._results_builder.add_absolute_result(PluginStateMetric(key=key, value=value, dimensions=dimensions,
                                                                       entity_selector=self.selector))


class Group(MetricSink):
    """
    Class used to store group data reported from the plugin.
    """
    def __init__(self, entity_id: int, name: str, technology: str, results_builder: ResultsBuilder) -> None:
        super().__init__(results_builder)
        self._name = name
        self._id = entity_id
        self._elements = {}

        if not technology:
            raise Exception("Plugin technologies is missing in plugin.json file")
        else:
            self._technology = technology[0].upper()

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name: str):
        self._name = name

    @property
    def id(self):
        return self._id

    @property
    def selector(self):
        return ExplicitSelector(self._id, EntityType.CUSTOM_DEVICE_GROUP)

    @property
    def technology(self):
        return self._technology

    def create_element(self, identifier: str, element_name: str) -> Element:
        """
        Adds a new element to the reported topology. Also calculates its id based on element name and identifier.

        Args:
            element_name: The name of the entity.
            identifier: Identifier used for element id calculation.
        Returns:
            The created element object.
        """
        element_id = hash_id(self._id, identifier)

        element = Element(element_name, element_id, self._technology, self._results_builder)

        self._elements[element_name] = element
        return element

    def get_elements(self):
        return self._elements


Topology = NamedTuple("Topology", [("group", Set[Group]), ("config_id", int)])


class TopologyBuilder:
    """
    Class storing topology data reported by plugins.
    """
    def __init__(self, config_id: int, plugin_name: str, tenant_id: str, technology: str, results_builder: ResultsBuilder) -> None:
        self._groups = {}
        self._config_id = config_id
        self._logger = logging.getLogger(__name__)
        self._technology = technology
        self._tenant_id = tenant_id
        self._plugin_name = plugin_name
        self._results_builder = results_builder

    def create_group(self, identifier: str, group_name: str) -> Group:
        """
        Creates a new group to the reported topology. Also calculates its id based on identifier and group name.

        Args:
            identifier: Mandatory identifier used for group id calculation.
            group_name: Mandatory name of the group.

        Returns:
            The created group object.
        """
        group_id = hash_id(self._tenant_id, self._plugin_name, identifier)
        if group_id in self._groups:
            return self._groups[group_id]
        else:
            group = Group(group_id, group_name, self._technology, self._results_builder)

        self._groups[group_id] = group
        return group



    # def get_group_id(self) -> EntityId:
    #     """
    #     Gets the calculated group id to allow the plugin to send metrics to it.
    #     """
    #     return self._group.id
    #
    # def add_technology(self, tech: str) -> None:
    #     """
    #     Adds a technology specifier to the group entity.
    #
    #     Args:
    #         tech: The string representing a technology.
    #     """
    #     self._group.add_technology(tech)

    def flush_result(self) -> Topology:
        """
        Clears the

        Returns:
            Group objects set.
        """
        groups = self._groups
        self._groups = {}
        return Topology(groups, self._config_id)
