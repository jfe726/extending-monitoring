import ruxit.tools.sdk_version
__version__ = ruxit.tools.sdk_version.get_version()
